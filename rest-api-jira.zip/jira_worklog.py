import requests
import pandas as pd
import sys
import json
from datetime import datetime
from getpass import getpass

# ============================================================
# НАСТРОЙКИ — измени под себя
# ============================================================
JIRA_URL = "https://jira.halykbank.kz"
USERNAME = "00060961"
# Пароль запрашивается при запуске (или задай ниже в переменную)
# PASSWORD = "твой_пароль"
# ============================================================

WORKLOG_API = f"{JIRA_URL}/rest/api/2/issue/{{issue_key}}/worklog"
COMMENT_API = f"{JIRA_URL}/rest/api/2/issue/{{issue_key}}/comment"


def load_excel(filepath):
    df = pd.read_excel(filepath, dtype=str)
    df.columns = df.columns.str.strip()
    required = ["Задача", "Дата", "Начало", "Часы", "Что сделано"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        print(f"Ошибка: в Excel не хватает колонок: {missing}")
        sys.exit(1)
    return df


def push_worklog(session, issue_key, date_str, start_time, hours, comment):
    started = f"{date_str}T{start_time}:00.000+0500"
    time_spent = f"{hours}h"

    # 1. Worklog
    wl_url = WORKLOG_API.format(issue_key=issue_key)
    wl_payload = {
        "started": started,
        "timeSpent": time_spent,
        "comment": comment
    }
    r = session.post(wl_url, json=wl_payload)
    if r.status_code in (200, 201):
        print(f"  ✅ Worklog: {issue_key} | {date_str} | {time_spent} — OK")
    else:
        print(f"  ❌ Worklog: {issue_key} | {date_str} — Ошибка {r.status_code}: {r.text[:200]}")
        return False

    # 2. Комментарий
    cm_url = COMMENT_API.format(issue_key=issue_key)
    cm_payload = {"body": f"[{date_str}] {comment}"}
    r = session.post(cm_url, json=cm_payload)
    if r.status_code in (200, 201):
        print(f"  ✅ Comment: {issue_key} | {date_str} — OK")
    else:
        print(f"  ⚠️ Comment: {issue_key} | {date_str} — Ошибка {r.status_code}: {r.text[:200]}")

    return True


def main():
    if len(sys.argv) < 2:
        print("Использование: python jira_worklog.py отчёт.xlsx")
        sys.exit(1)

    filepath = sys.argv[1]
    df = load_excel(filepath)

    # Запрос пароля
    try:
        password = PASSWORD
    except NameError:
        password = getpass(f"Введи пароль для {USERNAME}@Jira: ")

    session = requests.Session()
    session.auth = (USERNAME, password)
    session.headers.update({"Content-Type": "application/json"})

    # Проверка подключения
    r = session.get(f"{JIRA_URL}/rest/api/2/myself")
    if r.status_code != 200:
        print(f"❌ Не удалось подключиться к Jira: {r.status_code}")
        sys.exit(1)
    print(f"✅ Подключение к Jira: {r.json().get('displayName', 'OK')}\n")

    success, fail = 0, 0
    for i, row in df.iterrows():
        issue = row["Задача"].strip()
        date = row["Дата"].strip()
        start = row["Начало"].strip()
        hours = row["Часы"].strip()
        comment = row["Что сделано"].strip()

        print(f"[{i+1}/{len(df)}] {issue} — {date}")
        if push_worklog(session, issue, date, start, hours, comment):
            success += 1
        else:
            fail += 1
        print()

    print(f"\nИтого: ✅ {success} | ❌ {fail}")


if __name__ == "__main__":
    main()
