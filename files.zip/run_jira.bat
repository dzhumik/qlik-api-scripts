@echo off
cd /d C:\Users\00060961\Desktop\rest-api-jira
C:\Users\00060961\AppData\Local\Programs\Python\Python39\python.exe jira_worklog.py >> jira_log.txt 2>&1
