import requests
import pandas as pd
import sys
import json
import os
from datetime import datetime, date

# ============================================================
# НАСТРОЙКИ
# ============================================================
JIRA_URL = "https://jira.halykbank.kz"
USERNAME = "00060961"
PASSWORD = "april1100#1100#"
DEFAULT_FILE = "jira_april_2026.xlsx"
LOG_FILE = "submitted.log"
# ============================================================

WORKLOG_API = f"{JIRA_URL}/rest/api/2/issue/{{issue_key}}/worklog"
COMMENT_API = f"{JIRA_URL}/rest/api/2/issue/{{issue_key}}/comment"


def load_submitted():
    if not os.path.exists(LOG_FILE):
        return set()
    with open(LOG_FILE, "r", encoding="utf-8") as f:
        return set(line.strip() for line in f if line.strip())


def save_submitted(key):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(key + "\n")


def load_excel(filepath):
    df = pd.read_excel(filepath, dtype=str)
    df.columns = df.columns.str.strip()
    required = ["Задача", "Дата", "Начало", "Часы", "Что сделано"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        print(f"Ошибка: в Excel не хватает колонок: {missing}")
        sys.exit(1)
    return df


def clean_date(raw):
    return raw.strip()[:10]


def clean_time(raw):
    raw = raw.strip()
    if len(raw) >= 8 and raw.count(":") == 2:
        return raw[:5]
    return raw


def push_worklog(session, issue_key, date_str, start_time, hours, comment):
    started = f"{date_str}T{start_time}:00.000+05:00"
    time_spent = f"{hours}h"

    wl_url = WORKLOG_API.format(issue_key=issue_key)
    wl_payload = {
        "started": started,
        "timeSpent": time_spent,
        "comment": comment
    }

    r = session.post(wl_url, json=wl_payload)
    if r.status_code in (200, 201):
        print(f"  [OK] Worklog: {issue_key} | {date_str} | {time_spent}")
    else:
        print(f"  [FAIL] Worklog: {issue_key} | {date_str} — {r.status_code}: {r.text[:300]}")
        return False

    cm_url = COMMENT_API.format(issue_key=issue_key)
    cm_payload = {"body": f"[{date_str}] {comment}"}
    r = session.post(cm_url, json=cm_payload)
    if r.status_code in (200, 201):
        print(f"  [OK] Comment: {issue_key} | {date_str}")
    else:
        print(f"  [!] Comment: {issue_key} | {date_str} — {r.status_code}: {r.text[:300]}")

    return True


def main():
    if len(sys.argv) < 2:
        filepath = DEFAULT_FILE
    else:
        filepath = sys.argv[1]

    today = date.today()
    print(f"Дата: {today}\n")

    df = load_excel(filepath)
    submitted = load_submitted()

    session = requests.Session()
    session.auth = (USERNAME, PASSWORD)
    session.headers.update({"Content-Type": "application/json"})

    r = session.get(f"{JIRA_URL}/rest/api/2/myself")
    if r.status_code != 200:
        print(f"[FAIL] Не удалось подключиться к Jira: {r.status_code}")
        sys.exit(1)
    print(f"[OK] Подключение: {r.json().get('displayName', 'OK')}\n")

    success, skip, fail = 0, 0, 0
    for i, row in df.iterrows():
        issue = row["Задача"].strip()
        date_str = clean_date(row["Дата"])
        start = clean_time(row["Начало"])
        hours = row["Часы"].strip()
        comment = row["Что сделано"].strip()

        row_key = f"{issue}|{date_str}|{start}"

        row_date = date.fromisoformat(date_str)
        if row_date > today:
            print(f"[SKIP] {issue} — {date_str} (дата ещё не наступила)")
            skip += 1
            continue

        if row_key in submitted:
            print(f"[SKIP] {issue} — {date_str} (уже отправлено)")
            skip += 1
            continue

        print(f"[{i+1}/{len(df)}] {issue} — {date_str}")
        if push_worklog(session, issue, date_str, start, hours, comment):
            save_submitted(row_key)
            success += 1
        else:
            fail += 1
        print()

    print(f"\nИтого: OK {success} | SKIP {skip} | FAIL {fail}")


if __name__ == "__main__":
    main()
