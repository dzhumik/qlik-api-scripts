# -*- coding: utf-8 -*-
"""
Apps Inventory Report.

Выгружает список всех приложений из Qlik Sense Repository (QRS API)
с тремя полями: name, id, AppLevelMgmt (Custom Property из QMC).

QRS endpoint: /qrs/app/full
Custom Property вшит в каждую запись как массив customProperties[].

Запуск: python apps_report.py
Зависимости: requests, openpyxl
"""

import sys
from datetime import datetime
from pathlib import Path

import requests
import urllib3
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

QLIK_SERVER = "fdata1a003.halykbank.nb"
QLIK_USER = "UserDirectory=UNIVERSAL;UserId=00060961"

BASE_DIR = Path(__file__).parent
CLIENT_CERT = str(BASE_DIR / "certificate" / "client.pem")
CLIENT_KEY = str(BASE_DIR / "certificate" / "client_key.pem")
ROOT_CERT = str(BASE_DIR / "certificate" / "root.pem")

XRFKEY = "0123456789abcdef"
QRS_BASE = f"https://{QLIK_SERVER}:4242/qrs"

# Имя Custom Property, по которому классифицируются приложения в QMC.
CUSTOM_PROPERTY = "AppLevelMgmt"

REQUEST_HEADERS = {
    "X-Qlik-Xrfkey": XRFKEY,
    "X-Qlik-User": QLIK_USER,
    "Content-Type": "application/json",
}
REQUEST_PARAMS = {"xrfkey": XRFKEY}


# ---------------------------------------------------------------------------
# Excel styling
# ---------------------------------------------------------------------------

_HEADER_FONT = Font(name="Arial", size=11, bold=True, color="FFFFFF")
_HEADER_FILL = PatternFill("solid", start_color="1F4E78")
_TITLE_FONT = Font(name="Arial", size=14, bold=True, color="1F4E78")
_DATA_FONT = Font(name="Arial", size=10)
_BORDER = Border(
    left=Side(style="thin", color="BFBFBF"),
    right=Side(style="thin", color="BFBFBF"),
    top=Side(style="thin", color="BFBFBF"),
    bottom=Side(style="thin", color="BFBFBF"),
)
_CENTER = Alignment(horizontal="center", vertical="center")
_LEFT = Alignment(horizontal="left", vertical="center")


# ---------------------------------------------------------------------------
# QRS API
# ---------------------------------------------------------------------------

def qrs_get(endpoint):
    url = f"{QRS_BASE}/{endpoint}"
    try:
        return requests.get(
            url,
            headers=REQUEST_HEADERS,
            params=REQUEST_PARAMS,
            cert=(CLIENT_CERT, CLIENT_KEY),
            verify=ROOT_CERT,
            timeout=120,
        )
    except requests.RequestException as exc:
        sys.exit(f"[FATAL] QRS request failed: {exc}")


def fetch_apps():
    response = qrs_get("app/full")
    if response.status_code != 200:
        sys.exit(f"[FATAL] app/full -> {response.status_code}: {response.text[:300]}")
    return response.json()


# ---------------------------------------------------------------------------
# Data preparation
# ---------------------------------------------------------------------------

def _extract_custom_property(record, name):
    """Custom Property может быть назначен несколько раз с разными значениями.

    Собираем все значения через запятую - если их больше одного,
    в QMC так и отображается ('Production, Test'). Если ни одного - пустая строка.
    """
    values = []
    for cp in record.get("customProperties", []):
        definition = cp.get("definition") or {}
        if definition.get("name") == name:
            value = cp.get("value")
            if value:
                values.append(value)
    return ", ".join(values)


def prepare_apps(records):
    """Плоский список с тремя нужными полями, отсортированный по имени."""
    rows = []
    for rec in records:
        rows.append({
            "name": rec.get("name", ""),
            "id": rec.get("id", ""),
            "app_level": _extract_custom_property(rec, CUSTOM_PROPERTY),
        })
    rows.sort(key=lambda r: r["name"].lower())
    return rows


# ---------------------------------------------------------------------------
# Excel rendering
# ---------------------------------------------------------------------------

def _apply_header(ws, row, ncols):
    for col in range(1, ncols + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
        cell.alignment = _CENTER
        cell.border = _BORDER


def _apply_data(cell, alignment=_LEFT):
    cell.font = _DATA_FONT
    cell.alignment = alignment
    cell.border = _BORDER


def build_apps_sheet(ws, apps):
    ws["A1"] = "Реестр приложений Qlik Sense"
    ws["A1"].font = _TITLE_FONT
    ws.merge_cells("A1:C1")

    ws["A2"] = (
        f"Сформировано: {datetime.now():%d.%m.%Y %H:%M}  |  "
        f"Всего приложений: {len(apps)}"
    )
    ws["A2"].font = Font(name="Arial", size=10, italic=True, color="595959")
    ws.merge_cells("A2:C2")

    header_row = 4
    for col, header in enumerate(["Наименование отчёта", "ID", "AppLevelMgmt"], 1):
        ws.cell(row=header_row, column=col, value=header)
    _apply_header(ws, header_row, 3)

    last_row = header_row + len(apps)
    ws.auto_filter.ref = f"A{header_row}:C{last_row}"
    ws.freeze_panes = ws.cell(row=header_row + 1, column=1)

    row = header_row + 1
    for app in apps:
        ws.cell(row=row, column=1, value=app["name"])
        ws.cell(row=row, column=2, value=app["id"])
        ws.cell(row=row, column=3, value=app["app_level"])
        _apply_data(ws.cell(row=row, column=1), _LEFT)
        _apply_data(ws.cell(row=row, column=2), _LEFT)
        _apply_data(ws.cell(row=row, column=3), _LEFT)
        row += 1

    ws.column_dimensions["A"].width = 50
    ws.column_dimensions["B"].width = 40
    ws.column_dimensions["C"].width = 25


def save_excel(apps):
    wb = Workbook()
    ws = wb.active
    ws.title = "Apps"
    build_apps_sheet(ws, apps)

    filename = f"apps_report_{datetime.now():%Y%m%d_%H%M}.xlsx"
    filepath = BASE_DIR / filename
    wb.save(filepath)
    return filepath


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    print(f"Apps Inventory Report  |  {datetime.now():%d.%m.%Y %H:%M}")
    print(f"Server: {QLIK_SERVER}\n")

    print("Fetching apps...")
    apps = prepare_apps(fetch_apps())
    print(f"  {len(apps)} apps")

    classified = sum(1 for a in apps if a["app_level"])
    print(f"  {classified} with {CUSTOM_PROPERTY}, {len(apps) - classified} without")

    filepath = save_excel(apps)
    print(f"\nSaved: {filepath}")


if __name__ == "__main__":
    main()
