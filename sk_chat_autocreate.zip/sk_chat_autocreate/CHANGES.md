# Изменения sk_chat_autocreate — полный лог

## Обновлено: 14.04.2026

---

## Хронология работы

### Сессия 4 (14.04.2026) — Подготовка к защите продукта

#### 13. Бизнес-логика SK-Pharmacy в system prompt

**Проблема:** Пользователь не может указывать формулы, Set Analysis и точные имена полей при демо. AI должен понимать естественный язык.

**Решение:** Добавлен блок «БИЗНЕС-ЛОГИКА SK-PHARMACY» в system prompt:
- Описание всех ключевых полей и их смысла (КТП=флаг, Способ закупа=измерение, меры и т.д.)
- Паттерны интерпретации: «доля КТП» → Set Analysis с фильтром, «по регионам» → автовыбор поля
- Автовыбор меры: по умолчанию [План поставки на дату в KZT], для недопоставок/остатков — соответствующие поля
- Автовыбор измерения: «по регионам/препаратам/месяцам» → правильное поле из модели
- Примеры интерпретации: «доля КТП по способам закупа» → table с 3 мерами (часть, целое, доля)
- Правило: НЕ проси пользователя писать формулы, сам собери визуализацию

#### 14. КТП как идентификатор (не мера)

- Добавлен в regex `isId`: `|| /^(СПП|СКП|КТП)$/i.test(name)` → role="id"
- Добавлено правило в абсолютные запреты: «КТП — ФЛАГ (0/1), Sum([КТП]) — БЕССМЫСЛЕННО»

#### 15. Обновлены quick chips в шаблоне

Было: «Сколько регионов?», «Топ 10 препаратов», «Лидер по выручке»
Стало: «Доля КТП по закупкам», «Топ 10 препаратов», «КТП vs Импорт», «Сводная таблица»

---

### Сессия 1 (ранее — до 05.04.2026)

**Изучение расширения и базовые улучшения:**
- Изучена структура: 4 файла (js, html, css, qext), AngularJS + RequireJS + Qlik Engine API
- Динамический лимит строк в HyperCube: было 50 → стало до 200
- Строки с объектов листа: 10 → 100
- Добавлена функция `executeSetQueries` — точечные запросы через Set Analysis к Qlik Engine
- Двухпроходная логика Claude: первый проход может вернуть queries[], выполняются в движке, второй проход с результатами
- Модель сменена с claude-haiku-4-5-20251001 на claude-sonnet-4-6
- Добавлена поддержка listbox (фильтров)
- Добавлены правила для СПП/СКП (никогда не суммировать)
- Добавлены правила для табличных полей (измерение по умолчанию)
- Добавлены auto-queries (Count(Distinct) для измерений, Sum для мер) перед Claude
- Исправлены ошибки: JSON parse fallback, rate limit (429), кеш браузера

### Сессия 2 (05.04.2026)

#### 1. Копирование текста сообщений

**Проблема:** Qlik Sense блокирует выделение текста через CSS и JS. Пробовали:
- CSS `user-select: text !important` на `.sk-messages` и всех дочерних
- JS `stopPropagation` на `selectstart`/`mousedown` на контейнере
- `document.addEventListener` в capture phase
- `MutationObserver` для сброса `user-select: none`
- SVG иконки копирования с hover-эффектами через CSS `:hover`
- JS hover через `mouseenter`/`mouseleave` на `.sk-msg-wrap`
- JS hover через `mouseover` только на `.sk-msg-bubble`

**Ничего не работало** — Qlik перехватывает на уровне document в capture phase.

**Финальное решение:** Клик на любое сообщение тихо копирует текст:
- `template.html`: `ng-click="copyText(msg.content)"` на `.sk-msg-bubble`
- `sk_chat_autocreate.js`: `navigator.clipboard.writeText` + fallback `document.execCommand('copy')`
- Все иконки/кнопки убраны — невидимое действие

#### 2. Форматирование ответов AI (переносы строк)

**Проблема:** `\n` из JSON не рендерились — всё сплошным текстом.

**Решение:**
- `$sce` добавлен в зависимости контроллера
- `$scope.formatMsg(text)` — конвертирует `\n` → `<br>`, экранирует HTML
- Bot bubble: `ng-bind-html="formatMsg(msg.content)"` вместо `{{msg.content}}`
- System prompt: добавлен блок "СТИЛЬ ОТВЕТОВ" — по существу, с переносами, группировка по смыслу

#### 3. СПП и СКП — принудительно измерения (в коде)

**Проблема:** `loadAppSchema` классифицировал СПП/СКП как меры (числовые, card > 50).

**Решение:**
- Добавлен regex `|| /^(СПП|СКП)$/i.test(name)` в `isId` → role="id"
- System prompt: "СПП и СКП — это ИЗМЕРЕНИЯ (dimension), ВСЕГДА"

#### 4. SVG иконки вместо эмодзи

Все 12 типов визуализаций получили цветные SVG-иконки (24×24, Feather-style):
- barchart → зелёные столбцы (#4ade80)
- piechart → оранжевая круговая (#f97316)
- linechart → зелёный график (#34d399)
- pivot-table → жёлтая сетка (#fbbf24)
- table → серая (#94a3b8)
- kpi → фиолетовый (#a78bfa)
- gauge → розовый (#fb7185)
- combochart → голубой (#60a5fa)
- и т.д.

Рендеринг: `$scope.trustHtml(html)` + `ng-bind-html="trustHtml(s.icon)"`

**Важно:** SVG в Qlik Sense требуют inline `width`/`height` атрибуты — CSS классы не работают.

#### 5. Сводная таблица (pivot-table) — полный конструктор

**Пошаговый диалог (4 шага):**
1. Строки → fieldChips = измерения
2. Столбцы → fieldChips = оставшиеся + даты (или "пропустить")
3. Общий итог → по какому столбцу (или "Нет итогов", пропускается если столбцов нет)
4. Мера → поле + агрегация

**Создание:** Переделано с `enigmaApp.createObject()` на общий путь `app.visualization.create()` — тот же что для всех типов. Первый вариант создавал "голый" объект без измерений.

**Свойства:**
```javascript
qNoOfLeftDims = rowCount       // сколько полей в строках
qAlwaysFullyExpanded = true    // полностью развёрнутая
qIndentMode = false            // без отступов
qInterColumnSortOrder = [...]  // строки → столбцы → меры
```

**Общий итог:** `totalDimension` → `qShowTotal: true` + `qTotalLabel: "Итого"` + `qOtherTotalSpec.qTotalMode: "TOTAL_EXPR"`. Первая попытка с `qOtherCounted: 0` вызывала `Invalid method parameter(s)` — исправлено.

**Передача данных:** `applyClaudeResult` передаёт `rowFields`, `colFields`, `totalDimension`.

#### 6. Умное позиционирование объектов на листе

**Было:** Все объекты 12×7.

**Стало:** `TYPE_SIZES` — индивидуальные размеры:

| Тип | Размер | Логика |
|---|---|---|
| KPI | 6×3 | 4 в ряд |
| Gauge | 6×5 | небольшой |
| Listbox | 4×6 | узкий фильтр |
| Barchart/Linechart | 12×7 | 2 в ряд |
| Piechart | 8×7 | 3 в ряд |
| Combochart | 14×7 | чуть шире |
| Table/Pivot-table | 24×10 | полная ширина |
| Scatterplot | 12×8 | средний |
| Map | 14×8 | средний+ |

Приоритетный список — если идеальный не влезает, пробуются меньшие.

#### 7. Повторное создание объектов

**Было:** Галочка ✓ заменяла кнопку "+" навсегда.

**Стало:** Кнопка остаётся кликабельной — ✓ с зелёным фоном, при клике создаёт повторно.

#### 8. История чата

Лимит увеличен с 6 до 10 сообщений — хватает на 4 шага конструктора.

### Сессия 3 (06.04.2026)

#### 9. Ошибка создания pivot-table — Invalid method parameter(s)

**Причина:** Свойства `qOtherTotalSpec: { qOtherCounted: 0 }` и `qShowTotal: true` напрямую на dimension вызывали ошибку Engine API.

**Исправление:** Заменено на:
```javascript
d.qOtherTotalSpec = { qOtherMode: "OTHER_OFF", qTotalMode: "TOTAL_EXPR" };
d.qShowTotal = true;
d.qTotalLabel = { qv: "Итого" };
```

#### 10. Сортировка фильтра (listbox)

**Проблема:** Фильтр создавался с `qSortByLoadOrder: 1` — значения в случайном порядке загрузки.

**Исправление:**
```javascript
qSortCriterias: [{ qSortByState: 1, qSortByAscii: 1, qSortByNumeric: 1 }],
autoSort: true
```
- `qSortByState` — выбранные сверху
- `qSortByAscii` — по алфавиту
- `qSortByNumeric` — числа по возрастанию

#### 11. safeMeasure ломал Set Analysis

**Проблема:** `Sum({<Год={2026}>} [Остаток])` превращалось в `Sum([{<Год={2026}>} [Остаток]])` — regex `([A-Za-z]+)\(([^)]+)\)` не понимал вложенные скобки.

**Исправление:** Если выражение содержит `{` (Set Analysis) — не модифицировать, Claude сам оборачивает поля в `[]`.

```javascript
function safeMeasure(expr) {
  if (expr.indexOf("{") !== -1) return expr;
  // ... остальная логика для простых выражений
}
```

#### 12. API кредиты

Баланс Anthropic API закончился — ошибка `400: Your credit balance is too low`. Нужно пополнить на console.anthropic.com. API key в строке ~1255.

---

## Структура файлов

| Файл | Размер | Описание |
|---|---|---|
| `sk_chat_autocreate.js` | ~1500 строк | Вся логика |
| `template.html` | ~120 строк | UI (AngularJS) |
| `sk_chat_autocreate.css` | ~280 строк | Стили |
| `sk_chat_autocreate.qext` | манифест | Метаданные расширения |
| `CHANGES.md` | этот файл | Лог изменений |

## Ключевые участки кода (.js)

- **12-25**: `CHART_TYPES` — 12 типов с SVG иконками
- **44-65**: `safeField` / `safeMeasure` — обёртка полей с пробелами в [], не трогает Set Analysis
- **88-99**: `loadAppSchema` — классификация полей (СПП/СКП = id через regex)
- **199-304**: `loadQlikData` — агрегаты через HyperCube (до 200 строк)
- **555-656**: `executeSetQueries` — точечные Set Analysis запросы к движку
- **663-880**: `callClaude()` — system prompt (стиль ответов, правила полей, конструктор сводной 4 шага, паттерны фильтров/таблиц)
- **888**: История — последние 10 сообщений
- **948-1000**: `findBestFit()` — умное позиционирование по TYPE_SIZES
- **1030-1048**: listbox — автосортировка (state + ascii + numeric)
- **1078-1110**: pivot-table через visualization.create + colDefs
- **1226-1250**: Модификация свойств pivot-table (qNoOfLeftDims, qAlwaysFullyExpanded, totalDimension)
- **1276**: Контроллер — $sce, formatMsg, trustHtml, copyText
- **1492-1520**: applyClaudeResult — rowFields/colFields/totalDimension

## Что работает

- Пошаговый конструктор сводной таблицы (4 шага + создание)
- Создание 12 типов визуализаций с умным размером на листе
- Повторное создание объектов (кнопка остаётся кликабельной)
- Форматированные ответы с переносами строк (\n → <br>)
- Копирование текста по клику на сообщение
- SVG иконки в suggestions (12 типов)
- Two-pass Claude (queries[] → executeSetQueries → второй вызов)
- Set Analysis точечные запросы
- Фильтры (listbox) с автосортировкой
- Автоматические базовые запросы (Count(Distinct) + Sum)
- СПП/СКП всегда как измерение (код + промпт)
- safeMeasure не ломает Set Analysis выражения

## Известные ограничения / TODO

- Общий итог в сводной: `qShowTotal`/`qTotalMode` — протестировать работает ли после фикса
- Claude иногда не следует формату JSON — есть fallback обёртка
- Rate limit 30K токенов/мин — контекст обрезается до 60K символов
- Модель: claude-sonnet-4-6, max_tokens: 4000
- API key захардкожен (dev/demo) — строка ~1255
- CSS :hover не работает в Qlik — используем JS или невидимые действия
- SVG нужны inline width/height — CSS классы для размеров игнорируются Qlik

## Уроки (Qlik Sense extension development)

1. **Text selection невозможна** — Qlik блокирует на document capture phase. Единственное решение — click-to-copy.
2. **CSS :hover не работает** — Qlik перехватывает mouse events. Решение: JS event delegation.
3. **SVG sizing** — только inline атрибуты `width`/`height`, CSS классы игнорируются.
4. **pivot-table** — нельзя создавать через `enigmaApp.createObject()` напрямую, только через `visualization.create()` → модификация свойств → `createObject`.
5. **Set Analysis в мерах** — `safeMeasure` не должна трогать выражения с `{`, иначе ломает синтаксис.
6. **qOtherTotalSpec** — формат `{ qOtherCounted: число }` вызывает `Invalid method parameter(s)`, правильно `{ qOtherMode: "OTHER_OFF", qTotalMode: "TOTAL_EXPR" }`.
7. **Listbox сортировка** — `qSortByLoadOrder` даёт случайный порядок, нужно `qSortByState + qSortByAscii + qSortByNumeric`.
