define([
  "qlik",
  "jquery",
  "text!./template.html",
  "css!./sk_chat_autocreate.css"
], function (qlik, $, template) {
  "use strict";

  var GRID_COLS = 24;
  var STORAGE_KEY = "sk_chat_history";

  var CHART_TYPES = {
    barchart:      { title: "Столбчатая диаграмма", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="12" width="4" height="9" rx="1"/><rect x="10" y="7" width="4" height="14" rx="1"/><rect x="17" y="3" width="4" height="18" rx="1"/></svg>' },
    piechart:      { title: "Круговая диаграмма", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f97316" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-9-9"/><path d="M21 12H12V3"/></svg>' },
    linechart:     { title: "Линейный график", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>' },
    scatterplot:   { title: "Точечная диаграмма", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="7.5" r="2"/><circle cx="16.5" cy="16.5" r="2"/><circle cx="17" cy="7" r="2"/><circle cx="7" cy="17" r="2"/><path d="M3 3v18h18"/></svg>' },
    treemap:       { title: "Карта дерева", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="9" height="9" rx="1"/><rect x="13" y="2" width="9" height="5" rx="1"/><rect x="13" y="9" width="9" height="5" rx="1"/><rect x="2" y="13" width="5" height="9" rx="1"/><rect x="9" y="16" width="6" height="6" rx="1"/><rect x="17" y="16" width="5" height="6" rx="1"/></svg>' },
    "pivot-table": { title: "Сводная таблица", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/></svg>' },
    table:         { title: "Прямая таблица", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="3" x2="9" y2="21"/></svg>' },
    gauge:         { title: "Датчик", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fb7185" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>' },
    kpi:           { title: "KPI", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 3h5v5"/><path d="M8 3H3v5"/><path d="M12 22v-6"/><path d="m21 3-8.5 8.5"/><path d="M3 3l8.5 8.5"/><circle cx="12" cy="16" r="2"/></svg>' },
    combochart:    { title: "Комбо-диаграмма", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><rect x="7" y="13" width="3" height="5" rx="1"/><rect x="14" y="8" width="3" height="10" rx="1"/><path d="m6 7 4 4 4-4 5 5"/></svg>' },
    map:           { title: "Карта", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="10" r="3"/><path d="M12 2a8 8 0 0 0-8 8c0 5.4 7 11 8 12 1-1 8-6.6 8-12a8 8 0 0 0-8-8z"/></svg>' },
    listbox:       { title: "Фильтр", icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>' }
  };

  // Маппинг типов → реальные имена объектов Qlik
  var QLIK_TYPE_MAP = {
    barchart:    "barchart",
    piechart:    "piechart",
    linechart:   "linechart",
    scatterplot: "scatterplot",
    treemap:     "treemap",
    "pivot-table": "pivot-table",
    table:       "table",
    gauge:       "gauge",
    kpi:         "kpi",
    combochart:  "combochart",
    map:         "map",
    listbox:     "listbox"
  };

  // ── Утилиты полей ─────────────────────────────────────────────────────────
  function safeField(name) {
    if (/[ .()\u2116#\-\/\\]/.test(name)) return "[" + name + "]";
    return name;
  }
  function safeMeasure(expr) {
    if (!expr) return expr;
    // Если выражение содержит Set Analysis ({...}) — не трогаем,
    // Claude уже сам оборачивает поля в [] когда нужно
    if (expr.indexOf("{") !== -1) return expr;
    // Regex: [Поле (со скобками)] матчится как единое целое через \[[^\]]+\],
    // иначе [^)]+ ломает выражение на скобках внутри имени поля
    return expr.replace(/([A-Za-z]+)\(((?:(?:total|all|distinct)\s+)?\[[^\]]+\]|[^)]+)\)/gi, function(m, fn, field) {
      var f = field.trim();
      if (f.charAt(0) === "[" && f.charAt(f.length - 1) === "]") return fn + "(" + f + ")";
      // Квалификаторы Qlik: total, all, distinct — не оборачиваются в []
      var qualMatch = f.match(/^((?:total|all|distinct)\s+)(.+)$/i);
      if (qualMatch) {
        var kw = qualMatch[1];
        var fieldName = qualMatch[2].trim();
        if (fieldName.charAt(0) === "[") return fn + "(" + kw + fieldName + ")";
        return fn + "(" + kw + safeField(fieldName) + ")";
      }
      return fn + "(" + safeField(f) + ")";
    });
  }

  // Генератор уникальных cId для Qlik property panel
  function qlikCid() { return "sk" + Math.random().toString(36).substr(2, 9); }

  // ══════════════════════════════════════════════════════════════════════════
  // ── 1. УМНАЯ СХЕМА: определяем роль каждого поля + SAMPLE VALUES ────────
  // ══════════════════════════════════════════════════════════════════════════
  function loadAppSchema(app, onSuccess, onError) {
    var enigmaApp = app.model.enigmaModel;
    var schema = { tables: [], fields: [] };

    enigmaApp.createSessionObject({
      qInfo: { qType: "TableList" },
      qTableListDef: {}
    }).then(function(obj) {
      obj.getLayout().then(function(layout) {
        schema.tables = ((layout.qTableList && layout.qTableList.qItems) || []).map(function(t) {
          return { name: t.qName, rows: t.qNoOfRows };
        });
        try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}

        enigmaApp.createSessionObject({
          qInfo: { qType: "FieldList" },
          qFieldListDef: { qShowSystem: false, qShowHidden: false, qShowSemantic: false, qShowDerivedFields: false }
        }).then(function(obj2) {
          obj2.getLayout().then(function(layout2) {
            schema.fields = ((layout2.qFieldList && layout2.qFieldList.qItems) || []).map(function(f) {
              var name  = f.qName;
              var tags  = f.qTags || [];
              // qnTotalDistinctValues — основное поле, qDistinctValues — fallback
              var card  = f.qnTotalDistinctValues || f.qDistinctValues || f.qCardinal || 0;
              var isNum = tags.indexOf("$numeric") !== -1 || tags.indexOf("$integer") !== -1 || tags.indexOf("$float") !== -1;
              var isDate = tags.indexOf("$date") !== -1 || tags.indexOf("$timestamp") !== -1;

              // Поля-идентификаторы — никогда не суммируются, только Count
              var isId = /(_id|id_|^id$|_key|^key$|iин|бин|bin|iin|\bcode\b|\bнмк\b|\bокпо\b)/i.test(name)
                      || /^(СПП|СКП|КТП)$/i.test(name)
                      || (isNum && card > 10000); // много уникальных числ. значений = ID

              // Дата/время
              var isDateDim = isDate
                || /year|месяц|month|quarter|дата|date|период|week|день|day/i.test(name);

              // Реальные меры — числа для суммирования
              // card=0 означает неизвестную кардинальность — даём benefit of the doubt числовым полям
              var isMeasure = isNum && !isId && !isDateDim && (card === 0 || card > 50);

              // Всё остальное — измерение
              var role = isId ? "id" : isDateDim ? "date" : isMeasure ? "measure" : "dimension";

              return {
                name: name,
                role: role,
                isNumeric: isNum,
                cardValues: card,
                tags: tags.filter(function(t) { return t.charAt(0) === "$"; }),
                sampleValues: [] // будет заполнено ниже
              };
            });
            try { enigmaApp.destroySessionObject(obj2.id); } catch(e) {}

            // ── Загрузка sample values для каждого поля (кроме ID) ──────────
            // Берём до 8 значений для каждого измерения/даты/меры
            // Это критично: Claude ДОЛЖЕН видеть реальные данные, а не только имена полей
            var fieldsToSample = schema.fields.filter(function(f) {
              return f.role !== "id" && f.cardValues > 0 && f.cardValues <= 50000;
            });

            if (!fieldsToSample.length) {
              onSuccess(schema);
              return;
            }

            var sampleDone = 0;
            var sampleTotal = fieldsToSample.length;

            fieldsToSample.forEach(function(fieldInfo) {
              enigmaApp.createSessionObject({
                qInfo: { qType: "sk_sample" },
                qListObjectDef: {
                  qDef: { qFieldDefs: [fieldInfo.name] },
                  qShowAlternatives: false,
                  qInitialDataFetch: [{ qTop: 0, qLeft: 0, qHeight: 8, qWidth: 1 }]
                }
              }).then(function(listObj) {
                listObj.getLayout().then(function(listLayout) {
                  var items = (listLayout.qListObject &&
                               listLayout.qListObject.qDataPages &&
                               listLayout.qListObject.qDataPages[0] &&
                               listLayout.qListObject.qDataPages[0].qMatrix) || [];
                  fieldInfo.sampleValues = items.map(function(row) {
                    return row[0] ? (row[0].qText || "") : "";
                  }).filter(Boolean).slice(0, 8);
                  try { enigmaApp.destroySessionObject(listObj.id); } catch(e) {}
                  sampleDone++;
                  if (sampleDone === sampleTotal) {
                    console.log("[SK Schema] loaded with samples for", sampleTotal, "fields");
                    onSuccess(schema);
                  }
                }).catch(function() {
                  try { enigmaApp.destroySessionObject(listObj.id); } catch(e) {}
                  sampleDone++;
                  if (sampleDone === sampleTotal) onSuccess(schema);
                });
              }).catch(function() {
                sampleDone++;
                if (sampleDone === sampleTotal) onSuccess(schema);
              });
            });

          }).catch(function(e) { onError("FieldList: " + e.message); });
        }).catch(function(e) { onError("FieldList create: " + e.message); });
      }).catch(function(e) { onError("TableList: " + e.message); });
    }).catch(function(e) { onError("TableList create: " + e.message); });
  }

  function formatSchemaForClaude(schema) {
    var dims = [], meas = [], dates = [], ids = [];
    (schema.fields || []).forEach(function(f) {
      var samples = (f.sampleValues && f.sampleValues.length)
        ? " [примеры: " + f.sampleValues.join(", ") + "]"
        : "";
      // card:0 — кардинальность неизвестна из метаданных, но Count(Distinct) в queries даст точный ответ
      var cardStr = f.cardValues > 0 ? "(card:" + f.cardValues + ")" : "(card:неизвестно→используй Count(Distinct [" + f.name + "]) в queries)";
      if (f.role === "measure")   meas.push(f.name + cardStr + samples);
      else if (f.role === "date") dates.push(f.name + cardStr + samples);
      else if (f.role === "id")   ids.push(f.name + cardStr);
      else                        dims.push(f.name + cardStr + samples);
    });
    var lines = ["МОДЕЛЬ ДАННЫХ QLIK (ДИНАМИЧЕСКИ ОПРЕДЕЛЕНА):"];
    if (schema.tables.length) {
      lines.push("Таблицы: " + schema.tables.map(function(t){return t.name+"("+t.rows+" строк)";}).join(", "));
    }
    if (meas.length)  lines.push("МЕРЫ (суммируемые): " + meas.join(", "));
    if (dims.length)  lines.push("ИЗМЕРЕНИЯ (группировка): " + dims.join(", "));
    if (dates.length) lines.push("ДАТЫ/ПЕРИОДЫ: " + dates.join(", "));
    if (ids.length)   lines.push("ИДЕНТИФИКАТОРЫ (только Count): " + ids.join(", "));
    return lines.join("\n");
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── 2. ЗАГРУЗКА АГРЕГАТОВ ИЗ QLIK ENGINE ─────────────────────────────────
  // Отправляем несколько кубов по ключевым срезам, получаем готовые числа
  // ══════════════════════════════════════════════════════════════════════════
  function loadQlikData(app, schema, onSuccess, onError) {
    var enigmaApp = app.model.enigmaModel;
    if (!schema || !schema.fields || !schema.fields.length) { onSuccess({}, null, null); return; }

    var allFields = schema.fields;
    var dims  = allFields.filter(function(f){ return f.role === "dimension"; });
    var meas  = allFields.filter(function(f){ return f.role === "measure"; });
    var dates = allFields.filter(function(f){ return f.role === "date"; });

    // Если мер нет — всё равно строим кубы с Count() как мерой
    if (!meas.length) {
      // Попробуем использовать Count() как fallback меру
      var dimFallback = dims[0] || dates[0];
      if (!dimFallback) { onSuccess({}, null, null); return; }
      // Строим кубы Count по каждому измерению
      var fallbackMeas = [{ qDef: { qDef: "Count(1)", qLabel: "Кол-во записей" } }];
      var fallbackMainMeas = "Кол-во записей";
      var cubeListFallback = [];
      var seenFb = {};
      dims.concat(dates).forEach(function(f) {
        if (cubeListFallback.length < 8 && !seenFb[f.name]) {
          cubeListFallback.push([f.name, "dim_" + cubeListFallback.length]);
          seenFb[f.name] = 1;
        }
      });
      var cubeResultsFallback = {};
      var doneFb = 0;
      var totalFb = cubeListFallback.length;
      if (!totalFb) { onSuccess({}, null, null); return; }
      cubeListFallback.forEach(function(item) {
        var dimName = item[0], label = item[1];
        var maxRowsFb = Math.min(200, Math.floor(10000 / 2));
        enigmaApp.createSessionObject({
          qInfo: { qType: "sk_cube" },
          qHyperCubeDef: {
            qDimensions: [{ qDef: { qFieldDefs: [dimName] }, qNullSuppression: true }],
            qMeasures: fallbackMeas,
            qSortCriteria: [{ qSortByNumeric: -1 }],
            qInitialDataFetch: [{ qTop:0, qLeft:0, qHeight: maxRowsFb, qWidth: 2 }]
          }
        }).then(function(obj) {
          obj.getLayout().then(function(layout) {
            var rows = (layout.qHyperCube.qDataPages[0] && layout.qHyperCube.qDataPages[0].qMatrix) || [];
            var totalRows = layout.qHyperCube.qDimensionInfo[0] ? layout.qHyperCube.qDimensionInfo[0].qCardinal : rows.length;
            var hdrs = [dimName, fallbackMainMeas];
            var data = rows.map(function(r) {
              var o = {};
              hdrs.forEach(function(h, i) {
                var c = r[i];
                o[h] = (c.qText && c.qText !== "-") ? c.qText
                     : (c.qNum !== undefined && !isNaN(c.qNum) ? Math.round(c.qNum) : "-");
              });
              return o;
            });
            try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
            if (data.length) cubeResultsFallback[label] = { dim: dimName, headers: hdrs, data: data, totalDistinct: totalRows };
            doneFb++;
            if (doneFb === totalFb) onSuccess(cubeResultsFallback, fallbackMainMeas, null);
          }).catch(function() {
            try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
            doneFb++; if (doneFb === totalFb) onSuccess(cubeResultsFallback, fallbackMainMeas, null);
          });
        }).catch(function() { doneFb++; if (doneFb === totalFb) onSuccess(cubeResultsFallback, fallbackMainMeas, null); });
      });
      return;
    }

    // Определяем главные меры
    function find(fields, kwds) {
      for (var k=0; k<kwds.length; k++) {
        var kw = kwds[k].toLowerCase();
        for (var i=0; i<fields.length; i++)
          if (fields[i].name.toLowerCase().indexOf(kw)!==-1) return fields[i].name;
      }
      return fields[0] ? fields[0].name : null;
    }
    var mainMeas = find(meas, ["total_amount","totalamount","total","amount","сумма","revenue","выручка","продаж"])
                || meas[0].name;
    var secMeas  = find(meas, ["quantity","qty","кол","count","volume","объем"]);
    if (secMeas === mainMeas) secMeas = meas[1] ? meas[1].name : null;

    // Определяем ключевые измерения
    var dimProduct  = find(dims, ["productname","product_name","product","препарат","наименование","drug","товар"]);
    var dimRegion   = find(dims, ["region","регион","oblast","area","город","city"]);
    var dimCategory = find(dims, ["category","categor","категор","group","тип","вид","класс"]);
    var dimHospital = find(dims, ["hospital","больниц","clinic","мо_","facility","организ"]);
    var dimMonth    = find(dates, ["month_name","monthname","месяц","month"]);
    var dimYear     = find(dates, ["year","год"]);
    var dimDate     = find(dates, ["date","дата"]);

    // Берём ТОП-5 измерений для кубов (не дублируем)
    var cubeList = [];
    var seen = {};
    [
      [dimProduct,  "product"],
      [dimCategory, "category"],
      [dimRegion,   "region"],
      [dimHospital, "hospital"],
      [dimYear,     "year"],
      [dimMonth,    "month"],
    ].forEach(function(item) {
      if (item[0] && !seen[item[0]]) { cubeList.push(item); seen[item[0]]=1; }
    });
    // Добавляем любые неохваченные измерения (до 8 кубов)
    dims.forEach(function(f) {
      if (cubeList.length < 8 && !seen[f.name]) {
        cubeList.push([f.name, "dim_"+cubeList.length]);
        seen[f.name] = 1;
      }
    });

    var measDefs = [{ qDef: { qDef: "Sum(["+mainMeas+"])", qLabel: mainMeas } }];
    if (secMeas) measDefs.push({ qDef: { qDef: "Sum(["+secMeas+"])", qLabel: secMeas } });

    console.log("[SK Cubes] mainMeas:", mainMeas, "secMeas:", secMeas,
                "cubes:", cubeList.map(function(c){return c[1]+":"+c[0];}).join(", "));

    var cubeResults = {};
    var done = 0;
    var total = cubeList.length;

    if (!total) { onSuccess({}, mainMeas, secMeas); return; }

    cubeList.forEach(function(item) {
      var dimName = item[0], label = item[1];
      var nCols = 1 + measDefs.length;
      // Лимит Qlik Engine: qHeight × qWidth ≤ 10000 ячеек
      // Загружаем до 200 строк — достаточно для полного охвата большинства измерений
      var maxRows = Math.min(200, Math.floor(10000 / nCols));
      enigmaApp.createSessionObject({
        qInfo: { qType: "sk_cube" },
        qHyperCubeDef: {
          qDimensions: [{ qDef: { qFieldDefs: [dimName] }, qNullSuppression: true }],
          qMeasures: measDefs,
          qSortCriteria: [{ qSortByNumeric: -1 }],
          qInitialDataFetch: [{ qTop:0, qLeft:0, qHeight: maxRows, qWidth:nCols }]
        }
      }).then(function(obj) {
        obj.getLayout().then(function(layout) {
          var rows = (layout.qHyperCube.qDataPages[0] && layout.qHyperCube.qDataPages[0].qMatrix) || [];
          var totalRows = layout.qHyperCube.qDimensionInfo[0] ? layout.qHyperCube.qDimensionInfo[0].qCardinal : rows.length;
          var hdrs = [dimName, mainMeas].concat(secMeas ? [secMeas] : []);
          var data = rows.map(function(r) {
            var o = {};
            hdrs.forEach(function(h, i) {
              var c = r[i];
              o[h] = (c.qText && c.qText !== "-") ? c.qText
                   : (c.qNum !== undefined && !isNaN(c.qNum) ? Math.round(c.qNum) : "-");
            });
            return o;
          });
          try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
          if (data.length) cubeResults[label] = { dim: dimName, headers: hdrs, data: data, totalDistinct: totalRows };
          console.log("[SK Cube]", label, "(" + dimName + "):", data.length, "rows of", totalRows, "total");
          done++;
          if (done === total) onSuccess(cubeResults, mainMeas, secMeas);
        }).catch(function() {
          try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
          done++; if (done === total) onSuccess(cubeResults, mainMeas, secMeas);
        });
      }).catch(function() { done++; if (done === total) onSuccess(cubeResults, mainMeas, secMeas); });
    });
  }

  function formatDataForClaude(cubeResults, mainMeas, secMeas) {
    var keys = Object.keys(cubeResults || {});
    if (!keys.length) return "";
    // Динамический лимит: если уникальных ≤200 — показываем всё, иначе топ-200
    var lines = [
      "АГРЕГИРОВАННЫЕ ДАННЫЕ ИЗ QLIK ENGINE (посчитано по всем строкам, учтены выборки):",
      "Основная мера: " + mainMeas + (secMeas ? ", дополнительно: " + secMeas : ""),
      ""
    ];
    // Лимит строк для Claude — не более 20 на куб (топы достаточны для аналитики)
    // Точные числа всегда можно получить через queries[]
    var MAX_ROWS_CLAUDE = 20;
    // Порядок: product/category/region первыми, потом time, потом остальные
    var order = ["product","category","region","hospital","year","month"];
    var rendered = {};
    order.forEach(function(k) {
      if (!cubeResults[k]) return;
      rendered[k] = 1;
      var c = cubeResults[k];
      var total = c.totalDistinct || c.data.length;
      var showRows = c.data.slice(0, MAX_ROWS_CLAUDE);
      var countInfo = total > MAX_ROWS_CLAUDE
        ? " (всего уникальных: " + total + ", показано топ-" + showRows.length + ")"
        : " (всего: " + total + ")";
      lines.push("--- " + c.dim.toUpperCase() + countInfo + " ---");
      lines.push(c.headers.join("\t"));
      showRows.forEach(function(r) { lines.push(c.headers.map(function(h){return r[h];}).join("\t")); });
      lines.push("");
    });
    keys.forEach(function(k) {
      if (rendered[k]) return;
      var c = cubeResults[k];
      var total = c.totalDistinct || c.data.length;
      var showRows = c.data.slice(0, MAX_ROWS_CLAUDE);
      var countInfo = total > MAX_ROWS_CLAUDE
        ? " (всего уникальных: " + total + ", показано топ-" + showRows.length + ")"
        : " (всего: " + total + ")";
      lines.push("--- " + c.dim.toUpperCase() + countInfo + " ---");
      lines.push(c.headers.join("\t"));
      showRows.forEach(function(r) { lines.push(c.headers.map(function(h){return r[h];}).join("\t")); });
      lines.push("");
    });
    return lines.join("\n");
  }


  // ── Чтение выборок через enigma CurrentSelections ─────────────────────────
  function loadSelections(enigmaApp, onSuccess) {
    enigmaApp.createSessionObject({
      qInfo: { qType: "SelectionObject" },
      qSelectionObjectDef: {}
    }).then(function(obj) {
      obj.getLayout().then(function(layout) {
        var sels = (layout.qSelectionObject && layout.qSelectionObject.qSelections) || [];
        try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
        if (!sels.length) { onSuccess(""); return; }
        var lines = ["\nАКТИВНЫЕ ВЫБОРКИ (данные уже отфильтрованы):"];
        sels.forEach(function(s) {
          var vals = (s.qSelectedFieldSelectionInfo || [])
            .map(function(v) { return v.qName; })
            .filter(Boolean).slice(0, 15).join(", ");
          if (!vals) vals = s.qSelected || ("выбрано " + (s.qSelectedCount || ""));
          lines.push("  " + s.qField + " = " + vals);
        });
        lines.push("Анализируй только выбранные данные, упоминай фильтры в ответе.");
        onSuccess(lines.join("\n"));
      }).catch(function() {
        try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
        onSuccess("");
      });
    }).catch(function() { onSuccess(""); });
  }




  // ── Извлечение строк из qMatrix ─────────────────────────────────────────
  function extractMatrixRows(matrix, maxRows) {
    var rows = [];
    var limit = Math.min(matrix.length, maxRows);
    for (var ri = 0; ri < limit; ri++) {
      var row = matrix[ri];
      var vals = [];
      for (var ci = 0; ci < row.length; ci++) {
        vals.push(row[ci].qText || (row[ci].qNum !== undefined ? String(row[ci].qNum) : "-"));
      }
      rows.push(vals);
    }
    return rows;
  }

  // ── Чтение объектов листа С ДАННЫМИ ────────────────────────────────────────
  // Читаем не только properties (что за поля), но и layout (реальные числа)
  // Это критично: пользователь видит данные на графике и спрашивает о них!
  function loadSheetObjects(app, sheetId, onSuccess) {
    if (!sheetId) { onSuccess([]); return; }
    var enigmaApp = app.model.enigmaModel;

    enigmaApp.getObject(sheetId).then(function(sheetObj) {
      sheetObj.getProperties().then(function(sheetProps) {
        var cells = sheetProps.cells || [];
        if (!cells.length) { onSuccess([]); return; }

        var results = [];
        var done = 0;

        cells.forEach(function(cell) {
          enigmaApp.getObject(cell.name).then(function(obj) {
            // Читаем И properties (определения полей) И layout (реальные данные)
            var propsPromise = obj.getProperties();
            var layoutPromise = obj.getLayout();

            Promise.all([propsPromise, layoutPromise]).then(function(both) {
              var props = both[0];
              var layout = both[1];

              var info = {
                id:    cell.name,
                type:  (props.qInfo && props.qInfo.qType) || cell.type || "unknown",
                title: props.title || (props.qMetaDef && props.qMetaDef.title) || ""
              };

              // Определения полей из properties
              var hcDef = props.qHyperCubeDef || {};
              var dimDefs = (hcDef.qDimensions || []).map(function(d) {
                return (d.qDef && d.qDef.qFieldDefs && d.qDef.qFieldDefs[0]) || "";
              }).filter(Boolean);
              var measDefs = (hcDef.qMeasures || []).map(function(m) {
                return (m.qDef && m.qDef.qDef) || "";
              }).filter(Boolean);
              if (dimDefs.length) info.dimensions = dimDefs;
              if (measDefs.length) info.measures = measDefs;

              // РЕАЛЬНЫЕ ДАННЫЕ из layout (то что пользователь видит на графике)
              var hc = layout.qHyperCube;
              if (hc) {
                // Заголовки столбцов
                var colHeaders = [];
                (hc.qDimensionInfo || []).forEach(function(d) {
                  colHeaders.push(d.qFallbackTitle || (d.qGroupFieldDefs && d.qGroupFieldDefs[0]) || "dim");
                });
                (hc.qMeasureInfo || []).forEach(function(m) {
                  colHeaders.push(m.qFallbackTitle || "measure");
                });
                info.dataHeaders = colHeaders;
                info.totalRows = hc.qSize ? hc.qSize.qcy : 0;

                // Пробуем взять данные из layout.qDataPages
                var matrix = (hc.qDataPages && hc.qDataPages[0] && hc.qDataPages[0].qMatrix) || [];

                if (matrix.length > 0) {
                  // Данные есть в layout — берём до 100 строк
                  info.data = extractMatrixRows(matrix, 20);
                  results.push(info);
                  done++;
                  if (done === cells.length) onSuccess(results);

                } else if (info.totalRows > 0 && colHeaders.length > 0) {
                  // Данных нет в layout — запрашиваем явно через getHyperCubeData
                  // Это частая ситуация для sn-table и pivot-table
                  var fetchRows = Math.min(info.totalRows, 20);
                  obj.getHyperCubeData("/qHyperCubeDef", [
                    { qTop: 0, qLeft: 0, qHeight: fetchRows, qWidth: colHeaders.length }
                  ]).then(function(dataPages) {
                    var fetchedMatrix = (dataPages && dataPages[0] && dataPages[0].qMatrix) || [];
                    if (fetchedMatrix.length) {
                      info.data = extractMatrixRows(fetchedMatrix, 100);
                      console.log("[SK SheetObj] fetched", info.data.length, "rows for", info.title || info.type);
                    }
                    results.push(info);
                    done++;
                    if (done === cells.length) onSuccess(results);
                  }).catch(function() {
                    results.push(info);
                    done++;
                    if (done === cells.length) onSuccess(results);
                  });

                } else {
                  results.push(info);
                  done++;
                  if (done === cells.length) onSuccess(results);
                }
              } else {
                results.push(info);
                done++;
                if (done === cells.length) onSuccess(results);
              }
            }).catch(function() {
              // Fallback: если layout не получился — хотя бы properties
              obj.getProperties().then(function(props) {
                var info = {
                  id:    cell.name,
                  type:  (props.qInfo && props.qInfo.qType) || cell.type || "unknown",
                  title: props.title || ""
                };
                var hcDef = props.qHyperCubeDef || {};
                var dimDefs = (hcDef.qDimensions || []).map(function(d) {
                  return (d.qDef && d.qDef.qFieldDefs && d.qDef.qFieldDefs[0]) || "";
                }).filter(Boolean);
                var measDefs = (hcDef.qMeasures || []).map(function(m) {
                  return (m.qDef && m.qDef.qDef) || "";
                }).filter(Boolean);
                if (dimDefs.length) info.dimensions = dimDefs;
                if (measDefs.length) info.measures = measDefs;
                results.push(info);
                done++;
                if (done === cells.length) onSuccess(results);
              }).catch(function() { done++; if (done === cells.length) onSuccess(results); });
            });
          }).catch(function() { done++; if (done === cells.length) onSuccess(results); });
        });
      }).catch(function() { onSuccess([]); });
    }).catch(function() { onSuccess([]); });
  }

  function formatSheetForClaude(objects) {
    if (!objects || !objects.length) return "";
    var lines = ["\nОБЪЕКТЫ НА ЛИСТЕ (" + objects.length + "):"];
    objects.forEach(function(o, i) {
      var desc = (i + 1) + ". [" + o.type + "]";
      if (o.title) desc += " \"" + o.title + "\"";
      if (o.dimensions && o.dimensions.length) desc += " | Изм: " + o.dimensions.join(", ");
      if (o.measures && o.measures.length) desc += " | Меры: " + o.measures.join(", ");
      lines.push(desc);

      // Только заголовки + до 5 строк данных (экономия токенов)
      if (o.dataHeaders && o.data && o.data.length) {
        lines.push("  " + o.dataHeaders.join("\t"));
        var maxRows = Math.min(o.data.length, 5);
        for (var r = 0; r < maxRows; r++) {
          lines.push("  " + o.data[r].join("\t"));
        }
        if (o.data.length > 5) lines.push("  ...(+" + (o.data.length - 5) + " строк)");
      }
    });
    lines.push("Контекст листа — только для понимания что пользователь уже смотрит.");
    return lines.join("\n");
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── 5. ТОЧЕЧНЫЕ ЗАПРОСЫ: выполняем Set Analysis выражения в Qlik Engine ──
  // ══════════════════════════════════════════════════════════════════════════
  // Claude возвращает queries[] — массив {label, expr} с Set Analysis выражениями.
  // Мы создаём временный HyperCube для каждого, получаем точное значение из движка.
  // Поддерживаемые формы:
  //   Sum({<Field={'value'}>} Measure)          — фильтр по конкретному значению
  //   Sum({1<Field={'v1'}, Field2={'v2'}>} M)   — несколько фильтров без текущей выборки
  //   Sum({$<Year={2025}, Month={'март'}>} M)   — текущая выборка + уточнение
  //   Count(Distinct [Field])                   — количество уникальных значений
  //   Sum({<Date={'>2025-01-01'}>} M)           — диапазон дат
  function executeSetQueries(enigmaApp, queries, onSuccess) {
    if (!queries || !queries.length) { onSuccess([]); return; }
    var results = [];
    var done = 0;
    var total = queries.length;

    queries.forEach(function(q) {
      enigmaApp.createSessionObject({
        qInfo: { qType: "sk_setquery" },
        qHyperCubeDef: {
          qMeasures: [{ qDef: { qDef: q.expr, qLabel: q.label || "result" } }],
          qInitialDataFetch: [{ qTop: 0, qLeft: 0, qHeight: 1, qWidth: 1 }]
        }
      }).then(function(obj) {
        obj.getLayout().then(function(layout) {
          var val = "нет данных";
          try {
            var cell = layout.qHyperCube.qDataPages[0].qMatrix[0][0];
            val = (cell.qText && cell.qText !== "-" && cell.qText !== "")
              ? cell.qText
              : (cell.qNum !== undefined && !isNaN(cell.qNum) ? cell.qNum : "нет данных");
          } catch(e) {}
          try { enigmaApp.destroySessionObject(obj.id); } catch(e) {}
          results.push({ label: q.label, expr: q.expr, value: val });
          console.log("[SK SetQuery]", q.label, "=", val, " | expr:", q.expr);
          done++;
          if (done === total) onSuccess(results);
        }).catch(function(e) {
          try { enigmaApp.destroySessionObject(obj.id); } catch(e2) {}
          results.push({ label: q.label, expr: q.expr, value: "ошибка: " + (e.message || e) });
          done++;
          if (done === total) onSuccess(results);
        });
      }).catch(function(e) {
        results.push({ label: q.label, expr: q.expr, value: "ошибка создания объекта: " + (e.message || e) });
        done++;
        if (done === total) onSuccess(results);
      });
    });
  }

  // ── Claude API ─────────────────────────────────────────────────────────────
  function callClaude(apiKey, chatHistory, dataText, onSuccess, onError) {
    var systemPrompt = [
      "Ты — аналитик данных встроенный в Qlik Sense. Отвечай на РУССКОМ языке.",
      "",
      "СТИЛЬ: отвечай строго по существу. Используй \\n для читаемости, • для списков, ЗАГЛАВНЫЕ для заголовков.",
      "Пример: 'дай измерения' → \"analysis\":\"ИЗМЕРЕНИЯ:\\n\\n• Лот\\n• МНН\\n• Лекарственная форма\"",
      "Пример: 'сколько регионов?' → одна строка: 'В данных 8 регионов.'",
      "",
      "КОНТЕКСТ: тебе передаётся МОДЕЛЬ ДАННЫХ и АГРЕГАТЫ из Qlik Engine. Доверяй числам движка.",
      "",
      "МОДЕЛЬ ДАННЫХ:",
      "• МЕРЫ — числа для агрегации: Sum(), Avg(), Max(), Min()",
      "• ИЗМЕРЕНИЯ — категории для группировки (без агрегации)",
      "• ДАТЫ — Year, Month, Quarter для трендов",
      "• ИДЕНТИФИКАТОРЫ — коды, ID. НИКОГДА не суммируй. Только Count(Distinct [поле])",
      "  ВНИМАНИЕ: Count(Distinct [ID]) — правильно! Count([Distinct ID]) — ОШИБКА!",
      "",
      "АБСОЛЮТНЫЕ ЗАПРЕТЫ:",
      "• СПП, СКП — ТОЛЬКО ИЗМЕРЕНИЕ. Sum([СПП]), Sum([СКП]) — ЗАПРЕЩЕНО. Допустимо: Count(Distinct [СПП])",
      "• КТП — ФЛАГ (0/1), НЕ мера. Используй как фильтр: {<КТП={1}>}",
      "• Поля с 'номер','код','ID','ИИН','БИН' — только ИЗМЕРЕНИЕ",
      "",
      "ТАБЛИЦЫ: поля по умолчанию = ИЗМЕРЕНИЕ. Мера только если пользователь написал 'сумма','посчитай','итого'.",
      "Если не уверен — спроси: 'Поле [X] — показать как значение или посчитать?'",
      "",
      "АНАЛИЗ: источник цифр — ТОЛЬКО агрегаты из кубов. Нет цифр → используй queries[].",
      "Данные объектов листа — только для контекста. НИКОГДА не говори 'данных нет'.",
      "Нет агрегатов → НЕ отказывай, а запроси через queries[].",
      "ВСЕГДА предлагай 2-3 визуализации + детальную таблицу.",
      "",
      "ВИЗУАЛИЗАЦИИ:",
      "barchart — сравнение, топ N | linechart — тренды (Month/Year) | piechart/treemap — доли (Sum без деления, Qlik считает % сам)",
      "listbox — фильтр (одно поле, без мер) | table — dimensions[] + measures[{expr,label}] | gauge/kpi — одно число без измерений",
      "combochart — measure + measure2 (столбцы + линия) | scatterplot — связь двух мер",
      "Поля с пробелами → []. Set Analysis: Sum({<Поле={'значение'}>} Мера)",
      "КВАЛИФИКАТОРЫ total/all: пишутся ВНУТРИ функции ПЕРЕД полем, БЕЗ [] вокруг себя:",
      "  Sum(total [Поле]) — ПРАВИЛЬНО | Sum([total [Поле]]) — ОШИБКА!",
      "  Sum(total {<Set>} [Поле]) — ПРАВИЛЬНО | Sum([total Поле]) — ОШИБКА!",
      "",
      "TOP-N: 'топ 5' → topN:5. Точное число из запроса! >20 значений без указания → topN:10. linechart → без topN.",
      "",
      "QUERIES[] — точечные запросы к Qlik Engine:",
      "Любой вопрос 'сколько X' → queries:[{label:'...', expr:'Count(Distinct [X])'}]",
      "Нет нужных цифр → queries:[{label:'...', expr:'Sum([мера])'}]",
      "card:0 у поля → ОБЯЗАТЕЛЬНО Count(Distinct) через queries[]",
      "Count() → ТОЛЬКО в queries[], НИКОГДА в suggestions.",
      "",
      "SET ANALYSIS: {1} — весь датасет | {$} — текущая выборка | {$<Поле={'v'}>} — фильтр",
      "{1<A={'v1'}, B={'v2'}>} — несколько фильтров | {$<Date={'>2025-01-01'}>} — диапазон | {'Асп*'} — wildcard",
      "Одинарные кавычки = точное совпадение, двойные = регистронезависимое. Поля с пробелами → [Field Name].",
      "",
      "КОНСТРУКТОР ТАБЛИЦЫ (пошаговый диалог):",
      "Триггер: 'собери таблицу', 'создай таблицу', 'таблица', 'table'.",
      "ВАЖНО: НЕ генерируй поля сам! Строго спрашивай у пользователя, что он хочет.",
      "fieldChips — массив имён полей, отображаются как кликабельные кнопки (нажатие ДОБАВЛЯЕТ поле через запятую в поле ввода).",
      "",
      "ШАГ 1 — ИЗМЕРЕНИЯ:",
      "Спроси какие поля будут ИЗМЕРЕНИЯМИ. fieldChips = топ-10 измерений из модели данных.",
      "Пример:",
      "{\"analysis\":\"ТАБЛИЦА — шаг 1/3\\n\\nКакие поля добавить как измерения?\\nНажмите на нужные поля (они добавятся через запятую):\",",
      " \"fieldChips\":[\"МНН\",\"Лот\",\"Лекарственная форма\",\"Ед.изм\",\"Регион\",\"Способ закупа\",\"Год\",\"Квартал\",\"Месяц\",\"СПП\"],\"suggestions\":[]}",
      "",
      "ШАГ 2 — МЕРЫ:",
      "Запомни выбранные измерения. Спроси какие поля будут МЕРАМИ. fieldChips = все меры из модели.",
      "Пример:",
      "{\"analysis\":\"Измерения: МНН, Регион\\n\\nШаг 2/3 — какие поля показать как меры?\\nВыберите одно или несколько:\",",
      " \"fieldChips\":[\"План поставки на дату в KZT\",\"Остаток\",\"Недопоставка стационар\",\"Недопоставка АЛО\"],\"suggestions\":[]}",
      "",
      "ШАГ 3 — АГРЕГАЦИЯ:",
      "Запомни выбранные меры. Спроси как агрегировать каждую меру.",
      "fieldChips = варианты агрегации.",
      "Пример:",
      "{\"analysis\":\"Измерения: МНН, Регион\\nМеры: Остаток, План поставки на дату в KZT\\n\\nШаг 3/3 — как посчитать эти меры?\\nПо умолчанию Sum. Выберите другое или напишите 'готово':\",",
      " \"fieldChips\":[\"Sum\",\"Count\",\"Avg\",\"Min\",\"Max\",\"Готово\"],\"suggestions\":[]}",
      "",
      "ФИНАЛ — СОЗДАНИЕ:",
      "Собери suggestion с chartType:'table'. dimensions = выбранные измерения, measures = агрегированные меры.",
      "{\"analysis\":\"Таблица готова:\\n\\n- Измерения: МНН, Регион\\n- Меры: Sum(Остаток), Sum(План поставки на дату в KZT)\\n\\nНажми + чтобы создать:\",",
      " \"fieldChips\":[],",
      " \"suggestions\":[{\"chartType\":\"table\",\"dimensions\":[\"МНН\",\"Регион\"],",
      "  \"measures\":[{\"expr\":\"Sum([Остаток])\",\"label\":\"Остаток\"},{\"expr\":\"Sum([План поставки на дату в KZT])\",\"label\":\"План поставки\"}],",
      "  \"title\":\"МНН × Регион\",\"reason\":\"таблица по выбранным полям\"}]}",
      "",
      "ВАЖНО для конструктора таблицы:",
      "- Если пользователь пишет несколько полей через запятую — бери все.",
      "- По умолчанию агрегация = Sum. Если пользователь написал 'готово' или не указал — Sum для всех.",
      "- Если пользователь написал 'Count Остаток' — используй Count([Остаток]).",
      "- ПОМНИ контекст диалога — смотри историю сообщений чтобы знать что уже выбрано.",
      "",
      "КОНСТРУКТОР СВОДНОЙ ТАБЛИЦЫ (пошаговый диалог):",
      "Триггер: 'создай сводную таблицу', 'pivot таблица', 'сводная'.",
      "fieldChips — массив имён полей, отображаются как кликабельные кнопки (нажатие ДОБАВЛЯЕТ поле через запятую в поле ввода).",
      "",
      "ШАГ 1 — СТРОКИ:",
      "Спроси какие поля добавить в СТРОКИ. fieldChips = все измерения + id из модели.",
      "Пример:",
      "{\"analysis\":\"СВОДНАЯ ТАБЛИЦА — шаг 1/4\\n\\nКакие поля добавить в СТРОКИ?\\nВыбери одно или несколько (через запятую):\",",
      " \"fieldChips\":[\"Лот\",\"МНН\",\"Лекарственная форма\",\"Ед.изм\",\"СПП\",\"СКП\"],\"suggestions\":[]}",
      "",
      "ШАГ 2 — СТОЛБЦЫ:",
      "Запомни rowFields. Спроси какие поля в СТОЛБЦЫ. fieldChips = оставшиеся измерения + даты.",
      "Пример:",
      "{\"analysis\":\"Строки: МНН ✓\\n\\nШаг 2/4 — какие поля в СТОЛБЦЫ?\\nВыбери или 'пропустить':\",",
      " \"fieldChips\":[\"Год\",\"Квартал\",\"Месяц\",\"Лот\"],\"suggestions\":[]}",
      "",
      "ШАГ 3 — ОБЩИЙ ИТОГ:",
      "Запомни colFields. Спроси нужен ли общий итог и по какому столбцу.",
      "fieldChips = выбранные столбцы + 'Нет итогов'.",
      "Если столбцов нет (пропустили) — пропусти этот шаг и иди к мере.",
      "Пример:",
      "{\"analysis\":\"Строки: МНН ✓\\nСтолбцы: Год, Квартал ✓\\n\\nШаг 3/4 — Общий итог по какому столбцу?\\nВыбери столбец для итогов или 'нет итогов':\",",
      " \"fieldChips\":[\"Год\",\"Квартал\",\"Нет итогов\"],\"suggestions\":[]}",
      "",
      "Если пользователь выбрал столбец → totalDimension = имя поля.",
      "Если 'нет итогов' / 'пропустить' → totalDimension = null.",
      "",
      "ШАГ 4 — МЕРА:",
      "Спроси какую МЕРУ посчитать. fieldChips = все меры из модели.",
      "Пример:",
      "{\"analysis\":\"Строки: МНН ✓\\nСтолбцы: Год ✓\\nИтог: по Год ✓\\n\\nШаг 4/4 — какую МЕРУ посчитать?\\nНапиши поле и агрегацию (Sum/Count/Avg):\",",
      " \"fieldChips\":[\"Остаток\",\"Недопоставка стационар\",\"Недопоставка АЛО\"],\"suggestions\":[]}",
      "",
      "ФИНАЛ — СОЗДАНИЕ:",
      "Собери всё и выдай suggestion. Поле totalDimension — имя столбца для общего итога (или null).",
      "{\"analysis\":\"Сводная таблица готова:\\n\\n• Строки: МНН\\n• Столбцы: Год\\n• Итог по: Год\\n• Мера: Sum(Остаток)\\n\\nНажми + чтобы создать:\",",
      " \"fieldChips\":[],",
      " \"suggestions\":[{\"chartType\":\"pivot-table\",\"rowFields\":[\"МНН\"],\"colFields\":[\"Год\"],",
      "  \"totalDimension\":\"Год\",",
      "  \"measures\":[{\"expr\":\"Sum([Остаток])\",\"label\":\"Остаток\"}],",
      "  \"title\":\"Сводная: МНН × Год\",\"icon\":\"📋\",\"reason\":\"сводная таблица\"}]}",
      "",
      "ВАЖНО для конструктора:",
      "• Если пользователь пишет несколько полей через запятую — бери все.",
      "• Если 'пропустить'/'нет'/'без столбцов' — colFields=[] пустой, пропусти шаг итогов.",
      "• По умолчанию агрегация = Sum. Пользователь может указать Count, Avg, Max, Min.",
      "• ПОМНИ контекст диалога — смотри историю сообщений чтобы знать что уже выбрано.",
      "",
      "МОДИФИКАЦИЯ ОБЪЕКТОВ:",
      "Если пользователь просит добавить/удалить поле или меру в созданном объекте:",
      "1. Найди объект в списке 'СОЗДАННЫЕ ЧЕРЕЗ ЧАТ ОБЪЕКТЫ' по названию или смыслу запроса.",
      "2. Если неоднозначно (несколько похожих) — перечисли их и спроси какой именно.",
      "3. В analysis кратко опиши текущий состав объекта (измерения, меры) и что изменяешь.",
      "4. Верни modify с objectId и нужными операциями. suggestions=[] при модификации.",
      "",
      "Формат modify (все поля опциональны, указывай только нужные):",
      "{\"modify\":{\"objectId\":\"id из списка\",",
      "  \"addDimensions\":[\"НовоеПоле\"],\"removeDimensions\":[\"Поле\"],",
      "  \"addMeasures\":[{\"expr\":\"Sum([X])\",\"label\":\"Метка\"}],\"removeMeasures\":[\"Sum([X])\"],",
      "  \"changeMeasures\":[{\"old\":\"Sum([X])\",\"new\":\"Avg([X])\",\"label\":\"Новая метка\"}],",
      "  \"title\":\"Новый заголовок\"}}",
      "",
      "Примеры запросов на модификацию:",
      "• 'добавь поле Регион в таблицу' → modify: {objectId, addDimensions:['Регион']}",
      "• 'убери меру Остаток' → modify: {objectId, removeMeasures:['Sum([Остаток])']}",
      "• 'замени Sum на Avg для остатка' → modify: {objectId, changeMeasures:[{old:'Sum([Остаток])',new:'Avg([Остаток])',label:'Средний остаток'}]}",
      "• 'добавь колонку с суммой плана' → modify: {objectId, addMeasures:[{expr:'Sum([План поставки на дату в KZT])',label:'План поставки'}]}",
      "ВАЖНО: objectId бери ТОЛЬКО из списка созданных объектов. Если объекта нет в списке — скажи что можно модифицировать только созданные через чат объекты.",
      "",
      "ПАТТЕРН: создать ОДИН фильтр по конкретному полю:",
      "Пользователь: 'создай фильтр по региону' или 'добавь фильтр регион'",
      "→ queries:[{label:'Кол-во значений Регион', expr:'Count(Distinct [Регион])'}]",
      "→ suggestions ТОЛЬКО ОДНА: {chartType:'listbox', dimension:'Регион', title:'Фильтр: Регион'}",
      "→ В analysis напиши: 'В поле Регион X уникальных значений. Фильтр создан.'",
      "ВАЖНО: когда просят ОДИН конкретный фильтр — одна suggestion, никаких barchart/table дополнительно!",
      "",
      "ПАТТЕРН: СПИСОК ФИЛЬТРОВ (пользователь спрашивает 'покажи фильтры', 'какие фильтры есть', 'список фильтров', 'доступные фильтры'):",
      "→ Верни МНОГО suggestions, каждая с chartType:'listbox' — по одной на каждое ИЗМЕРЕНИЕ из модели данных.",
      "→ НЕ используй fieldChips, НЕ предлагай текстовые списки. Только suggestions с chartType:'listbox'.",
      "→ В reason покажи количество уникальных значений — бери из card:N, которое ты видишь в модели данных.",
      "→ НЕ разделяй по категориям. Просто плоский список всех измерений.",
      "",
      "Формат: {chartType:'listbox', dimension:'Поле', title:'Поле', reason:'N уникальных значений'}",
      "Бери N из card:N. Включай ВСЕ поля role=dimension и role=date. Не группируй, плоский список.",
      "",
      "ПАТТЕРН: поиск значения по конкретным фильтрам (договор, дата, SKU):",
      "Пользователь: 'у договора 03-26-0044-ALO-1BV за 31.01.2027 срок годности какое СПП'",
      "→ Определи какое поле = 'Номер договора', какое = 'Срок годности', искомое = 'СПП'",
      "→ Only() возвращает единственное значение измерения при фильтре:",
      "  queries: [{label:'СПП', expr:'Only({1<[Номер Договора]={\"03-26-0044-ALO-1BV\"}, [Срок Годности]={\"31.01.2027\"}>} [СПП])'}]",
      "→ Предложи таблицу: dimensions:['Номер Договора','Срок Годности','СПП'], measures:[]",
      "  (таблица с тремя измерениями покажет все строки — пользователь сам отфильтрует)",
      "",
      "Only({<Фильтры>} [Измерение]) — возвращает значение измерения если оно одно, иначе NULL.",
      "Concat({<Фильтры>} [Измерение], ', ') — возвращает все значения через запятую.",
      "",
      "БИЗНЕС-ЛОГИКА SK-PHARMACY:",
      "Датасет: фармацевтические закупки Казахстана (СК Фармация).",
      "",
      "КЛЮЧЕВЫЕ ПОЛЯ И ИХ СМЫСЛ:",
      "• КТП (Казахстанское Товарное Происхождение) — ФЛАГ: 1 = товар казахстанского производства, 0 = импорт.",
      "  Это НЕ числовая мера! Это бинарный флаг (0 или 1) для ФИЛЬТРАЦИИ через Set Analysis.",
      "  Sum([КТП]) — БЕССМЫСЛЕННО. Правильно: Sum({<КТП={1}>} [мера]) — сумма только по КТП товарам.",
      "• Способ закупа — категория способа закупки (ДД = прямой договор, и т.д.). Это ИЗМЕРЕНИЕ.",
      "• МНН — международное непатентованное наименование лекарства. ИЗМЕРЕНИЕ.",
      "• Лот, Лекарственная форма, Ед.изм — измерения товара.",
      "• Регион, Город, Область — географические измерения.",
      "• СПП, СКП — номера/коды. ТОЛЬКО измерения, НИКОГДА не суммировать.",
      "• План поставки на дату в KZT — ГЛАВНАЯ МЕРА (деньги в тенге). Если пользователь не указал меру — используй её.",
      "• Остаток — мера остатков на складе.",
      "• Недопоставка стационар, Недопоставка АЛО — меры недопоставок.",
      "• Год, Квартал, Месяц — временные измерения.",
      "",
      "ИНТЕРПРЕТАЦИЯ ЕСТЕСТВЕННОГО ЯЗЫКА:",
      "Пользователь говорит на обычном русском. НЕ проси формулы, Set Analysis, точные имена полей.",
      "СНАЧАЛА пойми смысл, ПОТОМ сам собери правильную визуализацию/таблицу.",
      "",
      "ПАТТЕРН 'ДОЛЯ' / 'ПРОЦЕНТ' / 'УДЕЛЬНЫЙ ВЕС':",
      "→ Это ВСЕГДА отношение: часть / целое.",
      "→ Для piechart/treemap: Qlik считает % САМ — клади только Sum с фильтром, БЕЗ деления.",
      "→ Для table: делай 3 колонки — часть, целое, доля (формула деления).",
      "",
      "Примеры интерпретации:",
      "• 'доля КТП по способам закупа' →",
      "  table: dimensions=['Способ закупа'], measures=[",
      "    {expr:'Sum({<КТП={1}>} [План поставки на дату в KZT])', label:'КТП (тг)'},",
      "    {expr:'Sum([План поставки на дату в KZT])', label:'Всего (тг)'},",
      "    {expr:'Sum({<КТП={1}>} [План поставки на дату в KZT]) / Sum([План поставки на дату в KZT])', label:'Доля КТП'}",
      "  ]",
      "  ИЛИ piechart: dimension='Способ закупа', measure='Sum({<КТП={1}>} [План поставки на дату в KZT])'",
      "",
      "",
      "СОРТИРОВКА МЕР В ТАБЛИЦАХ (план-факт / КТП vs не КТП):",
      "Когда в таблице есть разбивка по КТП и не КТП — группируй по КТП/не КТП, а НЕ по план/факт:",
      "  ПРАВИЛЬНО: План КТП, Факт КТП, План не КТП, Факт не КТП",
      "  НЕПРАВИЛЬНО: План КТП, План не КТП, Факт КТП, Факт не КТП",
      "Общее правило: сначала все меры по КТП (план, факт, доля), потом все меры по не КТП.",
      "",
      "• 'покажи закупки по регионам' → barchart: dimension='Регион', measure='Sum([План поставки на дату в KZT])'",
      "• 'сравни КТП и импорт' → combochart: measure='Sum({<КТП={1}>} [мера])' (КТП), measure2='Sum({<КТП={0}>} [мера])' (Импорт)",
      "• 'топ 10 МНН по недопоставкам' → barchart: dimension='МНН', measure='Sum([Недопоставка стационар])', topN:10",
      "• 'сколько КТП товаров?' → queries:[{expr:'Count(Distinct {<КТП={1}>} [МНН])'}]",
      "• 'остатки по лекарственным формам' → barchart: dimension='Лекарственная форма', measure='Sum([Остаток])'",
      "• 'покажи недопоставки по месяцам' → linechart: dimension='Месяц', measure='Sum([Недопоставка стационар])'",
      "• 'КТП по годам' → linechart: dimension='Год', measure='Sum({<КТП={1}>} [План поставки на дату в KZT])'",
      "• 'таблица закупок по МНН' → table: dimensions=['МНН'], measures=[{expr:'Sum([План поставки на дату в KZT])',label:'Сумма закупок'}]",
      "",
      "АВТОВЫБОР МЕРЫ (если пользователь НЕ указал конкретную):",
      "• По умолчанию → [План поставки на дату в KZT] (главная денежная мера)",
      "• 'недопоставка/дефицит' → [Недопоставка стационар] или [Недопоставка АЛО]",
      "• 'остаток/запас' → [Остаток]",
      "• Если не понятно — спроси ОДИН вопрос: 'Какой показатель посчитать: план поставки, остатки или недопоставки?'",
      "",
      "АВТОВЫБОР ИЗМЕРЕНИЯ (если пользователь НЕ указал):",
      "• 'по регионам' → поле с регионами из модели",
      "• 'по препаратам/лекарствам' → МНН",
      "• 'по месяцам/годам/кварталам' → Месяц/Год/Квартал",
      "• 'по способу закупа' → Способ закупа",
      "• 'по лот/лотам' → Лот",
      "",
      "ГЛАВНОЕ ПРАВИЛО: пользователь общается как человек.",
      "Не заставляй его писать формулы. Если запрос понятен — сразу предлагай визуализацию.",
      "Если неоднозначен — задай ОДИН короткий уточняющий вопрос, потом создай.",
      "",
      "ФОРМАТ ОТВЕТА — СТРОГО JSON, НИКАКОГО ТЕКСТА ДО/ПОСЛЕ:",
      "{\"analysis\":\"текст\", \"fieldChips\":[\"Поле1\"], \"queries\":[{\"label\":\"...\",\"expr\":\"Count(Distinct [X])\"}],",
      " \"suggestions\":[{\"chartType\":\"barchart\",\"dimension\":\"поле\",\"measure\":\"Sum([Мера])\",\"measureLabel\":\"метка\",\"title\":\"...\",\"reason\":\"зачем\",\"sortDesc\":true,\"topN\":5}],",
      " \"modify\":{\"objectId\":\"id\",\"addDimensions\":[],\"addMeasures\":[],\"removeDimensions\":[],\"removeMeasures\":[],\"changeMeasures\":[],\"title\":\"\"}}",
      "Типы: barchart, linechart, piechart, treemap, table, pivot-table, kpi, gauge, combochart, scatterplot, listbox.",
      "table: dimensions:[], measures:[{expr,label}]. pivot-table: rowFields:[], colFields:[], measures:[{expr,label}], totalDimension.",
      "combochart: measure + measure2. kpi: measure + measure2 (опционально).",
      "modify — только при модификации существующего объекта. Не возвращай modify при создании нового."
    ].join("\n");

    var messages = [];
    if (dataText) {
      messages.push({ role: "user", content: dataText });
      messages.push({ role: "assistant", content: '{"analysis":"Модель данных и агрегаты загружены. Готов к анализу.","suggestions":[]}' });
    }
    // Лимит истории — последние 10 сообщений (5 пар user/assistant)
    // чтобы хватало на пошаговый конструктор (4 шага) и не превышать лимит токенов
    var historyLimit = chatHistory.slice(-10);
    historyLimit.forEach(function(msg) {
      if (msg.role === "user") {
        messages.push({ role: "user", content: msg.content });
      } else if (msg.role === "assistant") {
        // Передаём только analysis, без suggestions — они уже отображены в UI
        var shortContent = msg.rawJson
          ? (function() {
              try {
                var p = JSON.parse(msg.rawJson);
                return JSON.stringify({ analysis: p.analysis || "", suggestions: [] });
              } catch(e) { return '{"analysis":"' + (msg.content||"") + '","suggestions":[]}'; }
            })()
          : '{"analysis":"' + (msg.content||"") + '","suggestions":[]}';
        messages.push({ role: "assistant", content: shortContent });
      }
    });

    fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 4000,
        system: systemPrompt,
        messages: messages
      })
    }).then(function(resp) {
      return resp.json().then(function(data) {
        if (!resp.ok) {
          var msg = "API " + resp.status;
          try { msg += ": " + data.error.message; } catch(e) {}
          onError(msg); return;
        }
        try {
          var raw = data.content[0].text.trim();
          raw = raw.replace(/^```json\s*/i,"").replace(/^```\s*/i,"").replace(/\s*```$/i,"").trim();
          var m = raw.match(/\{[\s\S]*\}/);
          if (m) {
            raw = m[0];
            onSuccess(JSON.parse(raw), raw);
          } else {
            // Claude ответил текстом вместо JSON — оборачиваем в корректный формат
            console.warn("[SK] Claude вернул текст вместо JSON, оборачиваем:", raw.substring(0, 100));
            var fallbackJson = JSON.stringify({ analysis: raw, suggestions: [], fieldChips: [] });
            onSuccess(JSON.parse(fallbackJson), fallbackJson);
          }
        } catch(e) {
          onError("JSON parse: " + e.message + " | " + (data.content[0] && data.content[0].text||"").substring(0,120));
        }
      });
    }).catch(function(e) { onError("Fetch: " + e.message); });
  }


  // ── Позиционирование (умное по типу визуализации) ────────────────────────
  // Идеальные размеры для каждого типа, от желаемого к допустимому
  var TYPE_SIZES = {
    "kpi":         [{w:6,h:3},{w:8,h:3},{w:6,h:4},{w:12,h:3}],
    "gauge":       [{w:6,h:5},{w:8,h:5},{w:6,h:6},{w:12,h:5}],
    "listbox":     [{w:4,h:6},{w:6,h:6},{w:4,h:8},{w:8,h:6}],
    "barchart":    [{w:12,h:7},{w:12,h:8},{w:14,h:7},{w:24,h:8}],
    "linechart":   [{w:12,h:7},{w:14,h:7},{w:12,h:8},{w:24,h:7}],
    "piechart":    [{w:8,h:7},{w:10,h:7},{w:12,h:7},{w:8,h:8}],
    "treemap":     [{w:12,h:7},{w:12,h:8},{w:14,h:7}],
    "combochart":  [{w:14,h:7},{w:12,h:7},{w:14,h:8},{w:24,h:8}],
    "scatterplot": [{w:12,h:8},{w:14,h:8},{w:12,h:7}],
    "table":       [{w:24,h:10},{w:24,h:8},{w:18,h:10},{w:14,h:8}],
    "pivot-table": [{w:24,h:10},{w:24,h:8},{w:18,h:10},{w:14,h:8}],
    "map":         [{w:14,h:8},{w:12,h:8},{w:14,h:10}]
  };
  var DEFAULT_SIZES = [{w:12,h:7},{w:12,h:6},{w:8,h:6},{w:24,h:7}];

  // Большие типы — всегда размещаются НИЖЕ существующих объектов
  var LARGE_TYPES = { "table": 1, "pivot-table": 1 };

  // Минимальные размеры — меньше этого объект будет выглядеть плохо (для стандартной 24-кол сетки)
  var TYPE_MIN = {
    "kpi":         {w:4, h:2},
    "gauge":       {w:4, h:3},
    "listbox":     {w:3, h:4},
    "barchart":    {w:6, h:5},
    "linechart":   {w:6, h:5},
    "piechart":    {w:6, h:5},
    "treemap":     {w:6, h:5},
    "combochart":  {w:6, h:5},
    "scatterplot": {w:6, h:5},
    "table":       {w:12, h:6},
    "pivot-table": {w:12, h:6},
    "map":         {w:6, h:5}
  };
  var DEFAULT_MIN = {w:6, h:4};

  function findBestFit(cells, gridRows, gridCols, chartType) {
    var baseSizes = TYPE_SIZES[chartType] || DEFAULT_SIZES;
    var scaleW = gridCols / GRID_COLS;
    var scaleH = gridRows > 14 ? gridRows / 14 : 1;

    // Идеальный размер (масштабированный)
    var ideal = baseSizes[0];
    var idealW = Math.round(ideal.w * scaleW);
    var idealH = Math.round(ideal.h * scaleH);

    // Минимальный допустимый размер (масштабированный)
    var baseMin = TYPE_MIN[chartType] || DEFAULT_MIN;
    var minW = Math.round(baseMin.w * scaleW);
    var minH = Math.round(baseMin.h * scaleH);

    // Карта занятости — поддержка col/row И bounds форматов
    var occ = {};
    var maxRow = 0;
    (cells || []).forEach(function(c) {
      var cr, cc2, crs, ccs;
      if (c.bounds) {
        cc2 = Math.floor(c.bounds.x / 100 * gridCols);
        cr  = Math.floor(c.bounds.y / 100 * gridRows);
        ccs = Math.ceil(c.bounds.width / 100 * gridCols);
        crs = Math.ceil(c.bounds.height / 100 * gridRows);
      } else {
        cc2 = c.col || 0;
        cr  = c.row || 0;
        ccs = c.colspan || 1;
        crs = c.rowspan || 1;
      }
      var bottom = cr + crs;
      if (bottom > maxRow) maxRow = bottom;
      for (var r = cr; r < bottom; r++)
        for (var col2 = cc2; col2 < cc2 + ccs; col2++)
          occ[r + "_" + col2] = true;
    });

    console.log("[SK findBestFit]", chartType, "grid:", gridCols, "x", gridRows,
      "maxRow:", maxRow, "ideal:", idealW, "x", idealH, "min:", minW, "x", minH);

    // Таблицы/сводные — всегда вниз. Остальное — ищем сверху.
    var startRow = LARGE_TYPES[chartType] ? maxRow : 0;
    var searchRows = Math.max(maxRow + 14, gridRows + 28);

    // Адаптивный поиск: для каждой позиции измеряем свободное место,
    // если >= минимума — вписываемся (до идеала)
    for (var row = startRow; row <= searchRows - minH; row++) {
      for (var col = 0; col <= gridCols - minW; col++) {
        // Быстрая проверка: левый верхний угол занят?
        if (occ[row + "_" + col]) continue;

        // Измеряем свободную ширину (до idealW)
        var freeW = 0;
        for (var dc = 0; dc < Math.min(idealW, gridCols - col); dc++) {
          var colOk = true;
          for (var dr = 0; dr < minH; dr++) {
            if (occ[(row + dr) + "_" + (col + dc)]) { colOk = false; break; }
          }
          if (!colOk) break;
          freeW = dc + 1;
        }
        if (freeW < minW) continue;

        // Измеряем свободную высоту для найденной ширины (до idealH)
        var freeH = minH; // мы уже проверили minH строк выше
        for (var dr = minH; dr < idealH; dr++) {
          var rowOk = true;
          for (var dc = 0; dc < freeW; dc++) {
            if (occ[(row + dr) + "_" + (col + dc)]) { rowOk = false; break; }
          }
          if (!rowOk) break;
          freeH = dr + 1;
        }

        console.log("[SK findBestFit] placed:", chartType,
          "at row:", row, "col:", col, freeW, "x", freeH,
          "(ideal:", idealW, "x", idealH + ")");
        return { col: col, row: row, colspan: freeW, rowspan: freeH };
      }
    }

    // Fallback — под всеми объектами, идеальный размер
    return { col: 0, row: maxRow, colspan: Math.min(idealW, gridCols), rowspan: idealH };
  }

  function getSheetId() {
    var m = window.location.href.match(/\/sheet\/([A-Za-z0-9_-]+)/);
    return m ? m[1] : null;
  }

  function isEditMode() {
    try { if (document.querySelector(".qv-sheet-edit-mode")) return true; } catch(e) {}
    try { if (window.location.href.indexOf("/state/edit") !== -1) return true; } catch(e) {}
    return false;
  }

  // ── Очередь создания — предотвращает наложение объектов при быстрых кликах ─
  var _createQueue = Promise.resolve();

  // ── Создание графика ──────────────────────────────────────────────────────
  function doCreate(app, enigmaApp, sheetId, suggestion, onSuccess, onFail) {
    _createQueue = _createQueue.then(function() {
      return new Promise(function(resolve) {
        _doCreateInner(app, enigmaApp, sheetId, suggestion,
          function(id, pos) { onSuccess(id, pos); resolve(); },
          function(e) { onFail(e); resolve(); }
        );
      });
    }).catch(function() {});
  }

  function _doCreateInner(app, enigmaApp, sheetId, suggestion, onSuccess, onFail) {
    enigmaApp.getObject(sheetId).then(function(sheetObj) {
      sheetObj.getProperties().then(function(sheetProps) {
        if (!Array.isArray(sheetProps.cells)) sheetProps.cells = [];
        var grid = { cols: sheetProps.columns || GRID_COLS, rows: sheetProps.rows || 14 };
        var qlikType = QLIK_TYPE_MAP[suggestion.chartType] || "barchart";
        var pos = findBestFit(sheetProps.cells, grid.rows, grid.cols, qlikType);
        if (!pos) { onFail("Нет места на листе"); return; }

        // ── Фильтр (listbox) — особый путь, без мер ──────────────────────────
        if (qlikType === "listbox") {
          var filterField = suggestion.dimension || "";
          var filterProps = {
            qInfo: { qType: "listbox" },
            qListObjectDef: {
              qDef: {
                qFieldDefs: [filterField],
                qSortCriterias: [{ qSortByState: 1, qSortByAscii: 1, qSortByNumeric: 1 }],
                autoSort: true
              },
              qShowAlternatives: true
            },
            title: suggestion.title || filterField,
            showTitles: true
          };
          enigmaApp.createObject(filterProps).then(function(persistObj) {
            sheetProps.cells.push({ name: persistObj.id, type: "listbox", col: pos.col, row: pos.row, colspan: pos.colspan, rowspan: pos.rowspan });
            sheetObj.setProperties(sheetProps).then(
              function() { onSuccess(persistObj.id, pos); },
              function(e) { onFail("setProperties: " + e); }
            );
          }, function(e) { onFail("createObject listbox: " + e); });
          return;
        }

        var rawMeasure = suggestion.measure || "";
        // Для piechart/treemap убираем деление — Qlik сам считает доли
        if ((qlikType === "piechart" || qlikType === "treemap") && rawMeasure.indexOf("/") !== -1) {
          rawMeasure = rawMeasure.split("/")[0].trim();
        }
        var meas = safeMeasure(rawMeasure);
        var sortDesc = suggestion.sortDesc !== false; // по умолчанию сортировка по убыванию

        // ── TOP-N через qOtherTotalSpec (Engine-level limiting) ──────────
        var topN = parseInt(suggestion.topN, 10);
        var otherSpec = {};
        if (topN > 0) {
          otherSpec = {
            qOtherMode: "OTHER_COUNTED",
            qOtherCounted: { qv: String(topN) },
            qOtherLabel: { qv: "Остальные" },
            qOtherSortMode: "OTHER_SORT_DESCENDING",
            qSuppressOther: true  // скрыть "Остальные" — чистый TOP-N
          };
          console.log("[SK] TOP-" + topN + " enabled via qOtherTotalSpec, suppress others: true");
        } else {
          console.log("[SK] No topN, creating without limitation");
        }

        // Измерение с сортировкой по убыванию меры
        var dimDef = {
          qDef: { qFieldDefs: [suggestion.dimension] },
          qNullSuppression: true,
          qOtherTotalSpec: otherSpec,
          qSortCriterias: sortDesc ? [{ qSortByExpression: -1, qExpression: { qv: meas } }] : [{ qSortByLoadOrder: 1 }]
        };

        // Процентный формат только для barchart/linechart с делением
        // Формат: Число / Простой / 1 000,12
        var NUM_FMT = { qType: "F", qnDec: 2, qUseThou: 1, qFmt: "# ##0,00", qDec: ",", qThou: " " };
        var PCT_FMT = { qType: "F", qnDec: 1, qUseThou: 0, qFmt: "# ##0,0%", qDec: ",", qThou: " " };
        // Определяет формат по выражению и лейблу
        function pickFmt(expr, label) {
          var e = (expr || "").toLowerCase(), l = (label || "").toLowerCase();
          if (e.indexOf("/") !== -1) return PCT_FMT;
          if (/доля|процент|%|удельн|share|ratio|percent/.test(l)) return PCT_FMT;
          return NUM_FMT;
        }
        // piechart и treemap сами умеют показывать доли
        var isRatio = meas.indexOf("/") !== -1;
        var autoPercentTypes = { piechart: 1, treemap: 1 };
        var numFormat = (isRatio && !autoPercentTypes[qlikType]) ? PCT_FMT : NUM_FMT;

        var measDef = { qDef: { qDef: meas, qLabel: suggestion.measureLabel || meas, qNumFormat: numFormat } };

        // ── Строим cols для visualization.create ──────────────────────────
        var colDefs;

        if (qlikType === "pivot-table") {
          // ── Сводная таблица — через visualization.create (сохраняет структуру свойств) ──
          var pvRowFields = suggestion.rowFields || suggestion.dimensions || [];
          if (!Array.isArray(pvRowFields)) pvRowFields = [pvRowFields];
          var pvColFields = suggestion.colFields || [];
          if (!Array.isArray(pvColFields)) pvColFields = [pvColFields];

          var pvMeasures = suggestion.measures || [];
          if (!Array.isArray(pvMeasures) && suggestion.measure) {
            pvMeasures = [{ expr: suggestion.measure, label: suggestion.measureLabel || suggestion.measure }];
          }

          colDefs = [];
          pvRowFields.forEach(function(f) {
            colDefs.push({
              qDef: { qFieldDefs: [f], qFieldLabels: [f], qSortCriterias: [{ qSortByLoadOrder: 1 }] },
              qNullSuppression: true
            });
          });
          pvColFields.forEach(function(f) {
            colDefs.push({
              qDef: { qFieldDefs: [f], qFieldLabels: [f], qSortCriterias: [{ qSortByLoadOrder: 1 }] },
              qNullSuppression: true
            });
          });
          pvMeasures.forEach(function(m) {
            var expr = safeMeasure(typeof m === "string" ? m : (m.expr || ""));
            var label = typeof m === "string" ? m : (m.label || expr);
            colDefs.push({ qDef: { qDef: expr, qLabel: label, qNumFormat: pickFmt(expr, label) } });
          });

          suggestion._pvRowCount = pvRowFields.length;
          suggestion._pvTotalDim = suggestion.totalDimension || null;
          console.log("[SK Pivot] rows:", pvRowFields, "cols:", pvColFields, "meas:", pvMeasures.length);

        } else if (qlikType === "table") {
          // ── Таблица — через visualization.create ──
          var rawDims = suggestion.dimensions || suggestion.dimension || "";
          var dimList = Array.isArray(rawDims)
            ? rawDims
            : String(rawDims).split(",").map(function(f){ return f.trim(); }).filter(Boolean);

          var rawMeasArr = suggestion.measures;
          var measList = [];
          if (Array.isArray(rawMeasArr) && rawMeasArr.length) {
            measList = rawMeasArr;
          } else if (suggestion.measure) {
            measList = [{ expr: suggestion.measure, label: suggestion.measureLabel || suggestion.measure }];
          }

          colDefs = [];
          dimList.forEach(function(f) {
            colDefs.push({
              qDef: { qFieldDefs: [f], qFieldLabels: [f], qSortCriterias: [{ qSortByLoadOrder: 1 }] },
              qNullSuppression: true
            });
          });
          measList.forEach(function(m) {
            var expr = safeMeasure(typeof m === "string" ? m : (m.expr || m.measure || ""));
            var label = typeof m === "string" ? m : (m.label || m.measureLabel || expr);
            colDefs.push({ qDef: { qDef: expr, qLabel: label, qNumFormat: pickFmt(expr, label) } });
          });

          console.log("[SK Table] dims:", JSON.stringify(dimList), "meas:", JSON.stringify(measList));

        } else if (qlikType === "scatterplot") {
          colDefs = [
            { qDef: { qFieldDefs: [suggestion.dimension] }, qNullSuppression: true },
            { qDef: { qDef: meas, qLabel: "X", qNumFormat: NUM_FMT } },
            { qDef: { qDef: meas, qLabel: "Y", qNumFormat: NUM_FMT } }
          ];
        } else if (qlikType === "gauge" || qlikType === "kpi") {
          var kpiLabel = suggestion.measureLabel || meas;
          colDefs = [{ qDef: { qDef: meas, qLabel: kpiLabel, qNumFormat: pickFmt(meas, kpiLabel) } }];
          if (qlikType === "kpi" && suggestion.measure2) {
            var meas2 = safeMeasure(suggestion.measure2);
            var kpiLabel2 = suggestion.measureLabel2 || meas2;
            colDefs.push({ qDef: { qDef: meas2, qLabel: kpiLabel2, qNumFormat: pickFmt(meas2, kpiLabel2) } });
          }
        } else if (qlikType === "combochart") {
          var comboDim = {
            qDef: { qFieldDefs: [suggestion.dimension] },
            qNullSuppression: true,
            qOtherTotalSpec: otherSpec,
            qSortCriterias: sortDesc ? [{ qSortByExpression: -1, qExpression: { qv: meas } }] : [{ qSortByLoadOrder: 1 }]
          };
          colDefs = [comboDim, measDef];
          if (suggestion.measure2) {
            var comboMeas2 = safeMeasure(suggestion.measure2);
            var comboLabel2 = suggestion.measureLabel2 || comboMeas2;
            colDefs.push({ qDef: { qDef: comboMeas2, qLabel: comboLabel2, qNumFormat: pickFmt(comboMeas2, comboLabel2) } });
          }
        } else {
          colDefs = [dimDef, measDef];
        }

        // ── Единый путь создания для всех типов ──────────────────────────
        app.visualization.create(
          qlikType,
          colDefs,
          { showTitles: true, title: suggestion.title || "" }
        ).then(function(vis) {
          enigmaApp.getObject(vis.id).then(function(sessionObj) {
            sessionObj.getProperties().then(function(sessionProps) {
              var pp = JSON.parse(JSON.stringify(sessionProps));
              delete pp.qInfo.qId;
              pp.qInfo.qType = qlikType;

              // ── Визуальные настройки ────────────────────────────────────
              // 1. Метки значений — всегда включены
              if (!pp.dataPoint) pp.dataPoint = {};
              pp.dataPoint.showLabels = true;

              // 2. Без сетки
              if (!pp.gridLine) pp.gridLine = {};
              pp.gridLine.auto = false;
              pp.gridLine.spacing = 0;

              // 3. Цвета — авто-режим (безопасно для всех типов)
              if (!pp.color) pp.color = {};
              pp.color.auto = true;

              // 4. Убедиться что cId есть + скрыть пустые значения по умолчанию
              if (pp.qHyperCubeDef) {
                pp.qHyperCubeDef.qSuppressMissing = true;
                pp.qHyperCubeDef.qSuppressZero = true;
                (pp.qHyperCubeDef.qDimensions || []).forEach(function(d) {
                  if (d.qDef && !d.qDef.cId) d.qDef.cId = qlikCid();
                  d.qNullSuppression = true;
                });
                (pp.qHyperCubeDef.qMeasures || []).forEach(function(m) {
                  if (m.qDef && !m.qDef.cId) m.qDef.cId = qlikCid();
                });
              }

              // 5. Для pivot-table: настройка строк/столбцов
              if (qlikType === "pivot-table" && pp.qHyperCubeDef) {
                pp.qHyperCubeDef.qNoOfLeftDims = suggestion._pvRowCount || 1;
                pp.qHyperCubeDef.qAlwaysFullyExpanded = true;
                pp.qHyperCubeDef.qIndentMode = false;

                if (suggestion._pvTotalDim) {
                  (pp.qHyperCubeDef.qDimensions || []).forEach(function(d) {
                    var fname = (d.qDef && d.qDef.qFieldDefs && d.qDef.qFieldDefs[0]) || "";
                    if (fname === suggestion._pvTotalDim) {
                      d.qOtherTotalSpec = { qOtherMode: "OTHER_OFF", qTotalMode: "TOTAL_EXPR" };
                      d.qShowTotal = true;
                      d.qTotalLabel = { qv: "Итого" };
                    }
                  });
                }
              }

              // 6. Для combochart: вторая мера как линия
              if (qlikType === "combochart" && suggestion.measure2) {
                // visualization.create уже добавила меры,
                // нужно настроить представление второй меры как линию
                var hcMeas = pp.qHyperCubeDef && pp.qHyperCubeDef.qMeasures;
                if (hcMeas && hcMeas.length >= 2) {
                  // Qlik combochart: each measure has barGrouping.grouping
                  // "stack"/"group" for bars, type "line" for line
                  if (!hcMeas[1].qDef) hcMeas[1].qDef = {};
                  // Set second measure rendering as line
                }
              }

              enigmaApp.createObject(pp).then(function(persistObj) {
                try { enigmaApp.destroyObject(vis.id); } catch(e) {}
                sheetProps.cells.push({ name: persistObj.id, type: qlikType, col: pos.col, row: pos.row, colspan: pos.colspan, rowspan: pos.rowspan });
                sheetObj.setProperties(sheetProps).then(
                  function() { onSuccess(persistObj.id, pos); },
                  function(e) { onFail("setProperties: " + e); }
                );
              }, function(e) { onFail("createObject: " + e); });
            }, function(e) { onFail("getProps: " + e); });
          }, function(e) { onFail("getObject: " + e); });
        }, function(e) { onFail("vis.create: " + e); });
      }, function(e) { onFail("sheetProps: " + e); });
    }, function(e) { onFail("getSheet: " + e); });
  }

  // ── Модификация существующего объекта ────────────────────────────────────
  function doModify(enigmaApp, modSpec, onSuccess, onFail) {
    var objectId = modSpec.objectId;
    if (!objectId) { onFail("objectId не указан"); return; }

    enigmaApp.getObject(objectId).then(function(obj) {
      obj.getProperties().then(function(props) {
        var hc = props.qHyperCubeDef;
        if (!hc) { onFail("Объект не содержит HyperCube"); return; }

        var NUM_FMT = { qType: "F", qnDec: 2, qUseThou: 1, qFmt: "# ##0,00", qDec: ",", qThou: " " };
        var PCT_FMT = { qType: "F", qnDec: 1, qUseThou: 0, qFmt: "# ##0,0%", qDec: ",", qThou: " " };
        function pickFmt(expr, label) {
          var e = (expr || "").toLowerCase(), l = (label || "").toLowerCase();
          if (e.indexOf("/") !== -1) return PCT_FMT;
          if (/доля|процент|%|удельн|share|ratio|percent/.test(l)) return PCT_FMT;
          return NUM_FMT;
        }

        // Удаление измерений
        if (modSpec.removeDimensions && modSpec.removeDimensions.length) {
          modSpec.removeDimensions.forEach(function(fieldName) {
            var norm = fieldName.replace(/[\[\]]/g, "").toLowerCase();
            hc.qDimensions = (hc.qDimensions || []).filter(function(d) {
              var f = ((d.qDef && d.qDef.qFieldDefs && d.qDef.qFieldDefs[0]) || "").replace(/[\[\]]/g, "").toLowerCase();
              return f !== norm;
            });
          });
        }

        // Удаление мер
        if (modSpec.removeMeasures && modSpec.removeMeasures.length) {
          modSpec.removeMeasures.forEach(function(exprToRemove) {
            var norm = exprToRemove.replace(/\s+/g, "").toLowerCase();
            hc.qMeasures = (hc.qMeasures || []).filter(function(m) {
              var mExpr = ((m.qDef && m.qDef.qDef) || "").replace(/\s+/g, "").toLowerCase();
              return mExpr !== norm;
            });
          });
        }

        // Изменение мер (замена формулы)
        if (modSpec.changeMeasures && modSpec.changeMeasures.length) {
          modSpec.changeMeasures.forEach(function(change) {
            var oldNorm = (change.old || "").replace(/\s+/g, "").toLowerCase();
            (hc.qMeasures || []).forEach(function(m) {
              var mExpr = ((m.qDef && m.qDef.qDef) || "").replace(/\s+/g, "").toLowerCase();
              if (mExpr === oldNorm) {
                m.qDef.qDef = safeMeasure(change["new"] || change.old);
                if (change.label) m.qDef.qLabel = change.label;
                m.qDef.qNumFormat = pickFmt(change["new"] || "", change.label || "");
              }
            });
          });
        }

        // Добавление измерений
        if (modSpec.addDimensions && modSpec.addDimensions.length) {
          if (!hc.qDimensions) hc.qDimensions = [];
          modSpec.addDimensions.forEach(function(fieldName) {
            hc.qDimensions.push({
              qDef: {
                qFieldDefs: [fieldName],
                qFieldLabels: [fieldName],
                cId: qlikCid(),
                qSortCriterias: [{ qSortByLoadOrder: 1 }]
              },
              qNullSuppression: true
            });
          });
        }

        // Добавление мер
        if (modSpec.addMeasures && modSpec.addMeasures.length) {
          if (!hc.qMeasures) hc.qMeasures = [];
          modSpec.addMeasures.forEach(function(m) {
            var expr = safeMeasure(typeof m === "string" ? m : (m.expr || ""));
            var label = typeof m === "string" ? m : (m.label || expr);
            hc.qMeasures.push({
              qDef: {
                qDef: expr,
                qLabel: label,
                cId: qlikCid(),
                qNumFormat: pickFmt(expr, label)
              }
            });
          });
        }

        // Изменение заголовка
        if (modSpec.title) {
          props.title = modSpec.title;
        }

        obj.setProperties(props).then(
          function() { onSuccess(objectId); },
          function(e) { onFail("setProperties: " + (e.message || e)); }
        );
      }).catch(function(e) { onFail("getProperties: " + (e.message || e)); });
    }).catch(function(e) { onFail("Объект не найден (id:" + objectId + "): " + (e.message || e)); });
  }

  // ─────────────────────────────────────────────────────────────────────────
  return {
    template: template,
    initialProperties: {},
    definition: {
      type: "items",
      component: "accordion",
      items: { settings: { uses: "settings" } }
    },
    support: {
      snapshot: false,
      export: false,
      exportData: false
    },

    controller: ["$scope", "$interval", "$timeout", "$sce", "$compile", function($scope, $interval, $timeout, $sce, $compile) {
      var app = qlik.currApp(), enigmaApp = app.model.enigmaModel;

      // ── API KEY ──────────────────────────────────────────────────────────
      var API_KEY = "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";

      // ── Форматирование текста: \n → <br> для отображения ─────────────────
      $scope.formatMsg = function(text) {
        if (!text) return $sce.trustAsHtml("");
        var safe = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        safe = safe.replace(/\n/g, "<br>");
        return $sce.trustAsHtml(safe);
      };
      $scope.trustHtml = function(html) {
        return $sce.trustAsHtml(html || "");
      };

      // ── State ────────────────────────────────────────────────────────────
      $scope.prompt = "";
      $scope.loading = false;
      $scope.status = "";
      $scope.messages = [];
      $scope.panelOpen = false;
      $scope.createdObjects = []; // Объекты созданные через чат — можно модифицировать
      $scope.chatIcon = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><circle cx="8" cy="10" r="1" fill="#fff" stroke="none"/><circle cx="12" cy="10" r="1" fill="#fff" stroke="none"/><circle cx="16" cy="10" r="1" fill="#fff" stroke="none"/></svg>';
      $scope.closeIcon = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';

      // ── Загрузка истории из localStorage ─────────────────────────────────
      try {
        var saved = localStorage.getItem(STORAGE_KEY);
        if (saved) $scope.messages = JSON.parse(saved);
      } catch(e) {}

      function saveHistory() {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify($scope.messages)); } catch(e) {}
      }

      function scrollToBottom() {
        $timeout(function() {
          var el = document.getElementById("sk-messages-container");
          if (el) el.scrollTop = el.scrollHeight;
        }, 50);
      }

      // ══════════════════════════════════════════════════════════════════════
      // ── SIDEBAR PANEL ─────────────────────────────────────────────────────
      // ══════════════════════════════════════════════════════════════════════
      var PANEL_WIDTH = 456;
      var panelEl = null;

      // Находим скроллируемый контейнер листа
      function getSheetContainer() {
        return document.querySelector(".qvt-sheet")
            || document.querySelector(".qv-panel-sheet")
            || document.querySelector("#grid")
            || document.querySelector(".qv-stage-container .qv-panel-content")
            || document.querySelector(".qv-panel-content");
      }

      // Определяем границы листа (ниже тулбара, выше футера)
      function getSheetBounds() {
        var sheetEl = getSheetContainer();
        if (sheetEl) {
          var r = sheetEl.getBoundingClientRect();
          return { top: Math.round(r.top), height: Math.round(r.height) };
        }
        // Fallback: ищем тулбар Qlik и начинаем ниже него
        var toolbar = document.querySelector(".qv-toolbar-container")
                   || document.querySelector(".qs-toolbar")
                   || document.querySelector('[tid="toolbar"]');
        var topOffset = toolbar ? Math.round(toolbar.getBoundingClientRect().bottom) : 0;
        return { top: topOffset, height: window.innerHeight - topOffset };
      }

      function buildPanel() {
        if (document.getElementById("sk-side-panel")) {
          panelEl = document.getElementById("sk-side-panel");
          return;
        }

        panelEl = document.createElement("div");
        panelEl.id = "sk-side-panel";

        // Панель фиксирована к правому краю, привязана к области листа
        var bounds = getSheetBounds();
        panelEl.style.cssText = [
          "position:fixed",
          "top:" + bounds.top + "px",
          "right:0",
          "width:0", "overflow:hidden",
          "height:" + bounds.height + "px",
          "z-index:100000",
          "transform:none",
          "transition:width .3s cubic-bezier(.4,0,.2,1)",
          "display:flex", "flex-direction:column",
          "background:#ffffff",
          "border-left:1px solid #e0e2e6",
          "box-shadow:-2px 0 12px rgba(0,0,0,.06)",
          "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
          "color:#1a1a2e", "font-size:13px"
        ].join(";");

        // Все стили inline — CSS файл не гарантирован для элементов вне расширения
        var S = {
          hdr: "display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#fff;border-bottom:1px solid #f0f1f3;flex-shrink:0",
          hdrL: "display:flex;align-items:center;gap:10px",
          ava: "width:34px;height:34px;background:#1a1a2e;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#fff;letter-spacing:.5px",
          title: "font-size:14px;font-weight:600;color:#1a1a2e",
          sub: "font-size:11px;color:#9ca3af;margin-top:1px",
          acts: "display:flex;align-items:center;gap:4px",
          ibtn: "background:none;border:none;cursor:pointer;width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#9ca3af",
          msgs: "flex:1;overflow-y:auto;padding:14px 12px;display:flex;flex-direction:column;gap:10px;scroll-behavior:smooth;background:#fafafa",
          inp: "display:flex;align-items:flex-end;gap:7px;padding:10px 12px;background:#fff;border-top:1px solid #f0f1f3;flex-shrink:0",
          ta: "flex:1;background:#f9fafb;border:1px solid #e5e7eb;border-radius:12px;color:#1a1a2e;font-size:13px;padding:9px 12px;resize:none;outline:none;font-family:inherit;line-height:1.5;max-height:100px",
          sbtn: "width:36px;height:36px;flex-shrink:0;background:#1a1a2e;border:none;border-radius:10px;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center",
          ubub: "background:#1a1a2e;color:#fff;padding:9px 13px;border-radius:16px 16px 4px 16px;max-width:80%;font-size:13px;line-height:1.5;cursor:pointer",
          bbub: "background:#fff;color:#374151;padding:9px 13px;border-radius:4px 16px 16px 16px;font-size:13px;line-height:1.55;border:1px solid #e8eaed;box-shadow:0 1px 3px rgba(0,0,0,.04);cursor:pointer",
          bava: "width:26px;height:26px;flex-shrink:0;background:#1a1a2e;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:#fff;margin-top:2px",
          chip: "display:inline-block;background:#f3f4f6;color:#374151;padding:4px 10px;border-radius:20px;margin:3px 3px 0 0;font-size:11px;cursor:pointer;border:1px solid #e5e7eb"
        };

        panelEl.innerHTML = [
          '<div style="' + S.hdr + '">',
          '  <div style="' + S.hdrL + '">',
          '    <div style="' + S.ava + '">AI</div>',
          '    <div>',
          '      <div style="' + S.title + '">Solai: SK-Pharmacy</div>',
          '      <div style="' + S.sub + '" ng-if="!loading">Готов к анализу</div>',
          '      <div style="' + S.sub + ';color:#6c63ff" ng-if="loading">{{status}}</div>',
          '    </div>',
          '  </div>',
          '  <div style="' + S.acts + '">',
          '    <button style="' + S.ibtn + '" ng-click="clearChat()" title="Очистить">',
          '      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
          '    </button>',
          '    <button style="' + S.ibtn + '" ng-click="togglePanel()" title="Закрыть">',
          '      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
          '    </button>',
          '  </div>',
          '</div>',
          '<div style="' + S.msgs + '" id="sk-messages-container">',
          '  <div ng-if="messages.length === 0" style="display:flex;align-items:flex-start;gap:7px">',
          '    <div style="' + S.bava + '">AI</div>',
          '    <div style="background:#fff;border:1px solid #e8eaed;border-radius:14px;padding:14px;box-shadow:0 1px 4px rgba(0,0,0,.05)">',
          '      <div style="font-size:13px;color:#6b7280;margin-bottom:10px;line-height:1.5">Привет! Я AI-аналитик SK-Pharmacy. Задай вопрос о данных.</div>',
          '      <div style="font-size:12px;color:#9ca3af;margin-bottom:6px">Попробуй:</div>',
          '      <span style="' + S.chip + '" ng-click="setPrompt(\'покажи долю КТП по способам закупа\')">Доля КТП</span>',
          '      <span style="' + S.chip + '" ng-click="setPrompt(\'топ 10 МНН по плану поставки\')">Топ 10 МНН</span>',
          '      <span style="' + S.chip + '" ng-click="setPrompt(\'сравни КТП и импорт по месяцам\')">КТП vs Импорт</span>',
          '      <span style="' + S.chip + '" ng-click="setPrompt(\'собери таблицу\')">Таблица</span>',
          '      <span style="' + S.chip + '" ng-click="setPrompt(\'создай сводную таблицу\')">Сводная</span>',
          '      <span style="' + S.chip + '" ng-click="setPrompt(\'покажи список фильтров\')">Фильтры</span>',
          '    </div>',
          '  </div>',
          '  <div ng-repeat="msg in messages track by $index" style="display:flex;flex-direction:column;gap:4px">',
          '    <div ng-if="msg.role===\'user\'" style="display:flex;justify-content:flex-end"><div style="' + S.ubub + '" ng-click="copyText(msg.content)">{{msg.content}}</div></div>',
          '    <div ng-if="msg.role===\'assistant\'" style="display:flex;align-items:flex-start;gap:7px">',
          '      <div style="' + S.bava + '">AI</div>',
          '      <div style="display:flex;flex-direction:column;gap:5px;max-width:86%">',
          '        <div style="' + S.bbub + '" ng-click="copyText(msg.content)" ng-bind-html="formatMsg(msg.content)"></div>',
          '        <div ng-if="msg.fieldChips.length" style="display:flex;flex-wrap:wrap;gap:4px;margin-top:3px">',
          '          <span style="' + S.chip + ';font-size:11px;padding:3px 9px" ng-repeat="chip in msg.fieldChips track by $index" ng-click="setPrompt(chip)">{{chip}}</span>',
          '        </div>',
          '        <div ng-if="msg.suggestions.length" style="display:flex;flex-direction:column;gap:5px">',
          '          <div ng-repeat="s in msg.suggestions track by $index" style="display:flex;align-items:center;justify-content:space-between;background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;padding:7px 9px">',
          '            <div style="display:flex;align-items:center;gap:7px;flex:1;min-width:0">',
          '              <span style="width:22px;height:22px;flex-shrink:0;display:flex;align-items:center;justify-content:center" ng-bind-html="trustHtml(s.icon)"></span>',
          '              <div style="min-width:0"><div style="font-size:12px;font-weight:500;color:#1f2937;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{s.title}}</div><div style="font-size:10px;color:#9ca3af;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{s.reason}}</div></div>',
          '            </div>',
          '            <button ng-if="!s.creating" ng-click="createChart(msg,s)" style="width:26px;height:26px;flex-shrink:0;background:#1a1a2e;border:none;border-radius:7px;color:#fff;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center" ng-style="s.done&&{\'background\':\'#f0fdf4\',\'color\':\'#16a34a\',\'border\':\'1px solid #bbf7d0\',\'font-size\':\'12px\'}">{{s.done?"✓":"＋"}}</button>',
          '            <span ng-if="s.creating" style="font-size:13px">⏳</span>',
          '          </div>',
          '        </div>',
          '      </div>',
          '    </div>',
          '    <div ng-if="msg.role===\'error\'" style="display:flex;justify-content:center"><div style="background:#fff5f5;color:#e53e3e;padding:6px 12px;border-radius:8px;font-size:12px;border:1px solid #fed7d7">⚠ {{msg.content}}</div></div>',
          '  </div>',
          '  <div ng-if="loading" style="display:flex;align-items:flex-start;gap:7px">',
          '    <div style="' + S.bava + '">AI</div>',
          '    <div style="' + S.bbub + ';display:flex;align-items:center;gap:4px;padding:12px 16px">',
          '      <span style="width:6px;height:6px;background:#d1d5db;border-radius:50%;display:inline-block"></span>',
          '      <span style="width:6px;height:6px;background:#d1d5db;border-radius:50%;display:inline-block"></span>',
          '      <span style="width:6px;height:6px;background:#d1d5db;border-radius:50%;display:inline-block"></span>',
          '    </div>',
          '  </div>',
          '</div>',
          '<div style="' + S.inp + '">',
          '  <textarea style="' + S.ta + '" ng-model="prompt" placeholder="Задай вопрос…" ng-keydown="onKeydown($event)" rows="1"></textarea>',
          '  <button style="' + S.sbtn + '" ng-click="sendMessage()" ng-disabled="loading||!prompt.trim()">',
          '    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
          '  </button>',
          '</div>'
        ].join("\n");

        document.body.appendChild(panelEl);
        $compile(panelEl)($scope);
        console.log("[SK] Sidebar panel injected, aligned to sheet bounds");
      }

      // ── Открыть / закрыть ──────────────────────────────────────────────
      $scope.togglePanel = function() {
        if (!panelEl) buildPanel();

        $scope.panelOpen = !$scope.panelOpen;
        var sheetEl = getSheetContainer();

        console.log("[SK Toggle] panelOpen:", $scope.panelOpen, "panelEl:", !!panelEl,
          "inDOM:", !!(panelEl && panelEl.parentNode), "sheetEl:", !!sheetEl);

        if ($scope.panelOpen) {
          // Гарантируем что панель в DOM
          if (panelEl && !panelEl.parentNode) {
            document.body.appendChild(panelEl);
          }
          // Привязываем к границам листа
          var bounds = getSheetBounds();
          panelEl.style.top = bounds.top + "px";
          panelEl.style.height = bounds.height + "px";
          panelEl.style.width = PANEL_WIDTH + "px";
          panelEl.style.overflow = "visible";

          if (sheetEl) {
            sheetEl.style.transition = "padding-right .3s cubic-bezier(.4,0,.2,1)";
            sheetEl.style.paddingRight = PANEL_WIDTH + "px";
          }
        } else {
          panelEl.style.width = "0";
          panelEl.style.overflow = "hidden";
          if (sheetEl) {
            sheetEl.style.paddingRight = "";
          }
        }

        scrollToBottom();
      };

      // Создаём панель при загрузке (скрытую)
      $timeout(function() { buildPanel(); }, 400);

      // ── Text selection в sidebar ──────────────────────────────────────────
      $timeout(function() {
        var container = document.getElementById("sk-messages-container");
        if (!container) return;
        function allowInContainer(e) {
          if (container.contains(e.target)) e.stopPropagation();
        }
        document.addEventListener("selectstart", allowInContainer, true);
        document.addEventListener("mousedown", allowInContainer, true);
        document.addEventListener("mouseup", allowInContainer, true);
        console.log("[SK] Text selection enabled in sidebar");
      }, 600);

      // ── Cleanup ──────────────────────────────────────────────────────────
      $scope.$on("$destroy", function() {
        if (panelEl && panelEl.parentNode) panelEl.parentNode.removeChild(panelEl);
        var sheetEl = getSheetContainer();
        if (sheetEl) sheetEl.style.paddingRight = "";
      });

      // ── Копировать текст по клику ─────────────────────────────────────────
      $scope.copyText = function(text) {
        if (!text) return;
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).catch(function() { fallbackCopy(text); });
        } else {
          fallbackCopy(text);
        }
      };
      function fallbackCopy(text) {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.cssText = "position:fixed;left:-9999px;top:-9999px;opacity:0";
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand("copy"); } catch(e) {}
        document.body.removeChild(ta);
      }

      $scope.clearChat = function() {
        $scope.messages = [];
        try { localStorage.removeItem(STORAGE_KEY); } catch(e) {}
      };

      $scope.setPrompt = function(text) {
        var cur = ($scope.prompt || "").replace(/\s+$/, "");
        if (cur) {
          // Append comma-separated if prompt already has text
          $scope.prompt = cur.replace(/,\s*$/, "") + ", " + text;
        } else {
          $scope.prompt = text;
        }
      };

      $scope.onKeydown = function(e) {
        if (e.keyCode === 13 && !e.shiftKey) {
          e.preventDefault();
          $scope.sendMessage();
        }
      };

      // ── Отправить сообщение ───────────────────────────────────────────────
      $scope.sendMessage = function() {
        var p = ($scope.prompt || "").trim();
        if (!p || $scope.loading) return;

        // Добавляем сообщение пользователя
        $scope.messages.push({ role: "user", content: p });
        $scope.prompt = "";
        $scope.loading = true;
        $scope.status = "Читаю схему…";
        saveHistory();
        scrollToBottom();

        // Шаг 1: схема
        loadAppSchema(app, function(schema) {
          var schemaText = formatSchemaForClaude(schema);
          $scope.$applyAsync(function() { $scope.status = "Загружаю данные…"; });

          // Шаг 2: данные через умные агрегации Qlik Engine
          loadQlikData(app, schema, function(cubeResults, mainMeas, secMeas) {
            var dataText = schemaText + "\n\n" + formatDataForClaude(cubeResults, mainMeas, secMeas);

            // Шаг 2.5: автоматические базовые запросы — Count(Distinct) для всех измерений
            // и Sum() для всех мер. Это даёт Claude гарантированные числа без угадывания.
            $scope.$applyAsync(function() { $scope.status = "Считаю метрики в движке…"; });
            var autoQueries = [];
            // Только Count(Distinct) для измерений и Sum для мер — без Avg
            // Максимум 6 запросов чтобы экономить токены
            (schema.fields || []).forEach(function(f) {
              if (autoQueries.length >= 6) return;
              if (f.role === "dimension") {
                autoQueries.push({ label: "Кол-во уникальных " + f.name, expr: "Count(Distinct [" + f.name + "])" });
              } else if (f.role === "measure") {
                autoQueries.push({ label: "Итого " + f.name, expr: "Sum([" + f.name + "])" });
              }
            });

            executeSetQueries(enigmaApp, autoQueries, function(autoResults) {
              if (autoResults.length) {
                dataText += "\n\nБАЗОВЫЕ МЕТРИКИ (посчитано автоматически из Qlik Engine):\n";
                autoResults.forEach(function(r) {
                  if (r.value !== "нет данных" && String(r.value).indexOf("ошибка") === -1) {
                    dataText += "• " + r.label + " = " + r.value + "\n";
                  }
                });
              }
              $scope.$applyAsync(function() { $scope.status = "Читаю выборки…"; });

            // Шаг 3: выборки через enigma SelectionObject (одноразовый, не реактивный)
            loadSelections(enigmaApp, function(selText) {
              if (selText) dataText += selText;

              $scope.$applyAsync(function() { $scope.status = "Читаю лист…"; });

              // Шаг 4: объекты листа
              var sheetId = getSheetId();
              loadSheetObjects(app, sheetId, function(sheetObjects) {
                if (sheetObjects.length) {
                  dataText += formatSheetForClaude(sheetObjects);
                }
                // Список объектов созданных через чат — Claude может их модифицировать
                if ($scope.createdObjects.length) {
                  dataText += "\n\nСОЗДАННЫЕ ЧЕРЕЗ ЧАТ ОБЪЕКТЫ (можно модифицировать через modify):";
                  $scope.createdObjects.forEach(function(o, i) {
                    dataText += "\n" + (i+1) + ". id:" + o.id + " [" + o.type + "] \"" + o.title + "\"";
                  });
                }
                // Защита от превышения лимита токенов: ~10000 токенов = ~40000 символов
                var MAX_CONTEXT_CHARS = 40000;
                if (dataText.length > MAX_CONTEXT_CHARS) {
                  dataText = dataText.substring(0, MAX_CONTEXT_CHARS) + "\n\n[контекст обрезан до лимита токенов]";
                  console.warn("[SK] Context truncated to", MAX_CONTEXT_CHARS, "chars");
                }
                console.log("[SK Context] size:", dataText.length, "chars, ~" + Math.round(dataText.length/4) + " tokens, sheet objects:", sheetObjects.length);
                $scope.$applyAsync(function() { $scope.status = "Solai: SK-Pharmacy думает…"; });

                // Шаг 5: Claude с историей
                function applyClaudeResult(result, rawJson) {
                  $scope.$applyAsync(function() {
                    $scope.loading = false;
                    $scope.status = "";

                    console.log("[SK Claude raw suggestions]:", JSON.stringify(result.suggestions));
                    var suggestions = (result.suggestions || []).map(function(s) {
                      var ct = CHART_TYPES[s.chartType] || { icon: "", title: s.chartType };
                      console.log("[SK] suggestion:", s.chartType, "topN:", s.topN, "title:", s.title);
                      return {
                        chartType:     s.chartType,
                        dimension:     s.dimension || "",
                        dimensions:    s.dimensions || [],
                        measure:       s.measure || "",
                        measure2:      s.measure2 || "",
                        measures:      s.measures || [],
                        measureLabel:  s.measureLabel || s.measure || "",
                        measureLabel2: s.measureLabel2 || s.measure2 || "",
                        title:         s.title || s.dimension || "",
                        reason:        s.reason || "",
                        icon:          ct.icon,
                        sortDesc:      s.sortDesc !== false,
                        topN:          s.topN || 0,
                        rowFields:       s.rowFields || [],
                        colFields:       s.colFields || [],
                        totalDimension:  s.totalDimension || null,
                        creating:      false,
                        done:          false
                      };
                    });

                    $scope.messages.push({
                      role:        "assistant",
                      content:     result.analysis || "",
                      rawJson:     rawJson,
                      suggestions: suggestions,
                      fieldChips:  result.fieldChips || []
                    });

                    saveHistory();
                    scrollToBottom();

                    // Обработка модификации объекта
                    if (result.modify && result.modify.objectId) {
                      console.log("[SK Modify] objectId:", result.modify.objectId, JSON.stringify(result.modify));
                      doModify(enigmaApp, result.modify,
                        function(objId) {
                          $scope.$applyAsync(function() {
                            var lastMsg = $scope.messages[$scope.messages.length - 1];
                            if (lastMsg && lastMsg.role === "assistant") {
                              lastMsg.content = (lastMsg.content || "") + "\n\n[Объект обновлён]";
                            }
                            saveHistory();
                            scrollToBottom();
                          });
                        },
                        function(err) {
                          $scope.$applyAsync(function() {
                            $scope.messages.push({ role: "error", content: "Ошибка модификации: " + err, suggestions: [], fieldChips: [] });
                            saveHistory();
                            scrollToBottom();
                          });
                        }
                      );
                    }
                  });
                }

                function onClaudeError(err) {
                  $scope.$applyAsync(function() {
                    $scope.loading = false;
                    $scope.status = "";
                    $scope.messages.push({ role: "error", content: err });
                    saveHistory();
                    scrollToBottom();
                  });
                }

                callClaude(API_KEY, $scope.messages, dataText,
                  function(result, rawJson) {
                    // Если Claude вернул queries[] — выполняем их в Qlik Engine
                    if (result.queries && result.queries.length) {
                      console.log("[SK] Claude запросил точечные данные:", result.queries.length, "выражений");
                      $scope.$applyAsync(function() { $scope.status = "Уточняю данные в движке…"; });

                      executeSetQueries(enigmaApp, result.queries, function(queryResults) {
                        var queryText = "\n\n═══════════════════════════════════════════════════\n";
                        queryText += "ТОЧНЫЕ РЕЗУЛЬТАТЫ ИЗ QLIK ENGINE (только что посчитано):\n";
                        queryText += "═══════════════════════════════════════════════════\n";
                        queryResults.forEach(function(r) {
                          queryText += "• " + r.label + " = " + r.value + "\n";
                        });
                        queryText += "═══════════════════════════════════════════════════\n";
                        queryText += "ИНСТРУКЦИЯ: используй эти числа в analysis. Дай прямой ответ пользователю с конкретным числом.\n";
                        console.log("[SK SetQuery results]:", queryText);

                        $scope.$applyAsync(function() { $scope.status = "Solai: SK-Pharmacy финализирует ответ…"; });
                        // Второй вызов Claude с точными данными из движка
                        callClaude(API_KEY, $scope.messages, dataText + queryText,
                          function(result2, rawJson2) { applyClaudeResult(result2, rawJson2); },
                          onClaudeError
                        );
                      });
                    } else {
                      applyClaudeResult(result, rawJson);
                    }
                  },
                  onClaudeError
                );
              }); // loadSheetObjects
            }); // loadSelections
            }); // executeSetQueries (шаг 2.5)
          },
          function(err) {
            $scope.$applyAsync(function() {
              $scope.loading = false;
              $scope.status = "";
              $scope.messages.push({ role: "error", content: "Данные: " + err });
              saveHistory();
            });
          });
        },
        function(err) {
          $scope.$applyAsync(function() {
            $scope.loading = false;
            $scope.status = "";
            $scope.messages.push({ role: "error", content: "Схема: " + err });
            saveHistory();
          });
        });
      };

      // ── Создать график ────────────────────────────────────────────────────
      $scope.createChart = function(msg, suggestion) {
        var sheetId = getSheetId();
        if (!sheetId) {
          $scope.messages.push({ role: "error", content: "ID листа не найден" });
          saveHistory(); return;
        }

        suggestion.creating = true;

        doCreate(app, enigmaApp, sheetId, suggestion,
          function(newId, pos) {
            $scope.$applyAsync(function() {
              suggestion.creating = false;
              suggestion.done = true;
              $scope.createdObjects.push({
                id: newId,
                title: suggestion.title || "",
                type: suggestion.chartType || ""
              });
              saveHistory();
            });
          },
          function(e) {
            $scope.$applyAsync(function() {
              suggestion.creating = false;
              $scope.messages.push({ role: "error", content: "Ошибка: " + e });
              saveHistory();
            });
          }
        );
      };

      scrollToBottom();
    }],

    paint: function($element, layout) {
      var scope = angular.element($element[0]).scope();
      if (scope) scope.layout = layout;

      // Убираем границы/фон контейнера Qlik (.qv-object) — кнопка AI без рамок
      var el = $element[0];
      while (el && el !== document.body) {
        el = el.parentElement;
        if (el && el.classList && (el.classList.contains("qv-object") || el.classList.contains("qv-inner-object"))) {
          el.style.border = "none";
          el.style.boxShadow = "none";
          el.style.background = "transparent";
        }
      }

      return qlik.Promise.resolve();
    }
  };
});